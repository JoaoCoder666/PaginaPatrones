package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.EstudianteInterfaz;

public class EstudianteConcreto implements EstudianteInterfaz{
	
	//Variable para asignar un Observado(Curso) al observador(Estudiante)
	private CursoConcreto curso;
	private String nombre;
	
	//Constructor que inicializa al Curso y asigna un nombre al estudiante
	public EstudianteConcreto(CursoConcreto c, String nom)
	{
		setCurso(c);
		setNombre(nom);
	}
	
	//Metodo que imprime en pantalla el nombre del estudiante, nombre de la nueva asignacion y el curso donde se añadió. Esto solo cuando el metodo es llamado por su Curso con el metodo notificar()
	@Override
	public String actualizar() 
	{
		return "\n------\nEstudiante: " + this.nombre + "\nNueva asignacion: " + this.curso.getUltimaAsignacion() + "\nEn el curso: " + this.curso.getNombreCurso() + "\n------\n";
	}

	//Setters & Getters
	public CursoConcreto getCurso() {
		return curso;
	}

	public void setCurso(CursoConcreto curso) {
		this.curso = curso;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
