package co.edu.udistrital.model.concreto;

import java.util.ArrayList;
import co.edu.udistrital.model.abstracto.CursoInterfaz;
import co.edu.udistrital.model.abstracto.EstudianteInterfaz;

public class CursoConcreto implements CursoInterfaz{
	//lista de Estudiantes suscritos al Curso
	private ArrayList<EstudianteInterfaz> lista;
	
	//variables para el nombre del curso y el titulo de la ultima asignacion creada
	private String nombreCurso;
	private String ultimaAsignacion;
	
	//constructor que inicializa la lista de estudiantes
	public CursoConcreto(String nombreC)
	{
		this.setNombreCurso(nombreC);
		lista = new ArrayList<EstudianteInterfaz>();
	}
	
	//metodo para agregar estudiantes al curso
	@Override
	public String agregar(EstudianteInterfaz estC) 
	{
		lista.add(estC);
		
		return "Estudiante suscrito al curso";
	}

	//metodo para eliminar estudiantes del curso
	@Override
	public String borrar(EstudianteInterfaz estC) 
	{
		lista.remove(estC);
		
		return "Estudiante eliminado del curso";
	}

	//Metodo que recorre todos los objetos de la lista llamando sus metodos actualizar() para notificar el cambio que se acaba de realizar, es este caso, la creación de una nueva asignacion
	@Override
	public String notificar() 
	{
		String salida = "";
		
		for(EstudianteInterfaz estudiante: lista)
		{
			salida += estudiante.actualizar();
		}
		
		return salida;
	}
	
	//Metodo para "crear" una nueva asignación
	public String nuevaAsignacion(String titulo) 
	{
		this.setUltimaAsignacion(titulo);
		
		return this.notificar();
	}

	//Setters & Getters
	public String getUltimaAsignacion() {
		return ultimaAsignacion;
	}

	public void setUltimaAsignacion(String ultimaAsignacion) {
		this.ultimaAsignacion = ultimaAsignacion;
	}

	public String getNombreCurso() {
		return nombreCurso;
	}

	public void setNombreCurso(String nombreCurso) {
		this.nombreCurso = nombreCurso;
	}
}
