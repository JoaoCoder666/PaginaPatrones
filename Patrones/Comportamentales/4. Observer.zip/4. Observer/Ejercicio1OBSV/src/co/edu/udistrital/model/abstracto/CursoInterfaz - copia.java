package co.edu.udistrital.model.abstracto;

public interface CursoInterfaz {
	//Metodos para agregar y eliminar observadores(Estudiantes) 
	public String agregar(EstudianteInterfaz est);
	public String borrar(EstudianteInterfaz est);
	//Metodo que llamará al metodo actualizar() de todos los observadores(Estudiantes)
	public String notificar();
}
