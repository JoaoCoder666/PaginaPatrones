package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.SuscriptorInterfaz;

public class Suscriptores implements SuscriptorInterfaz{
	private String nombre;
	private Canal canal;
	
	public Suscriptores(String nombre, Canal canal)
	{
		this.nombre = nombre;
		this.canal = canal;
	}
	
	@Override
	public String actualizacion()
	{
		return "\n---------\n\u2022" + this.nombre + ": Nuevo video en " + this.canal.getNombre() + "\n---------\n";
	}
}
