package co.edu.udistrital.model.abstracto;

public interface SuscriptorInterfaz {
	public String actualizacion();
}
