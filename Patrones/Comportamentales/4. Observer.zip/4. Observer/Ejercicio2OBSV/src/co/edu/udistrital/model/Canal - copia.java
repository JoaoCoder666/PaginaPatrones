package co.edu.udistrital.model;

import java.util.ArrayList;

import co.edu.udistrital.model.abstracto.CanalInterfaz;
import co.edu.udistrital.model.abstracto.SuscriptorInterfaz;

public class Canal implements CanalInterfaz{
	private String nombre;
	private String nuevoVideo;
	private ArrayList<SuscriptorInterfaz> lista;
	
	public Canal(String nombre)
	{
		this.setNombre(nombre);
		lista = new ArrayList<>();
	}
	
	@Override 
	public String suscripcion(SuscriptorInterfaz suscriptor)
	{
		lista.add(suscriptor);
		return "Cuenta Suscrita al canal!";
	}
	
	@Override
	public String desuscripcion(SuscriptorInterfaz suscriptor)
	{
		lista.remove(suscriptor);
		return "Cuenta desuscrita del canal!";
	}
	
	@Override
	public String notificar()
	{
		String salida = "";
		
		for(SuscriptorInterfaz suscriptor: lista)
		{
			salida += suscriptor.actualizacion();
		}
		
		return salida;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getNuevoVideo() {
		return nuevoVideo;
	}

	public String setNuevoVideo(String nuevoVideo) 
	{
		this.nuevoVideo = nuevoVideo;
		return notificar();
	}
}

