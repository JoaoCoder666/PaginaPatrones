package co.edu.udistrital.model.abstracto;

public interface CanalInterfaz {
	public String suscripcion(SuscriptorInterfaz suscriptor);
	public String desuscripcion(SuscriptorInterfaz suscriptor);
	public String notificar();
}
