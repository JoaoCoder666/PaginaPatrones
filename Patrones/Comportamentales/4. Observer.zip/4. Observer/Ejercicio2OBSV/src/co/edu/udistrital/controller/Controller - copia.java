package co.edu.udistrital.controller;

import co.edu.udistrital.model.Canal;
import co.edu.udistrital.model.Suscriptores;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		Canal canal = new Canal("Canal Videojuegos");
		
		Suscriptores sus1 = new Suscriptores("Juanito666", canal);
		Suscriptores sus2 = new Suscriptores("Vane666", canal);
		
		canal.suscripcion(sus1);
		canal.suscripcion(sus2);
		
		while(true)
		{
			String nombreVid = vista.leerCadenaDeTexto("Ingrese el nombre del nuevo video: ");
			vista.mostrarInformacion(canal.setNuevoVideo(nombreVid));
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2. no"));
			
			if(cont == 1)
			{
				cont = 0;
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}