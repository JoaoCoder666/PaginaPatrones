package co.edu.udistrital.model;

import java.util.ArrayList;
import co.edu.udistrital.model.abstracto.ObservadoresInterfaz;
import co.edu.udistrital.model.abstracto.UbicacionInterfaz;

public class Ubicacion implements UbicacionInterfaz{
	private String ultimaPosicion;
	private ArrayList<ObservadoresInterfaz> lista;
	
	public Ubicacion()
	{
		lista = new ArrayList<ObservadoresInterfaz>();
	}
	
	@Override
	public String agregar(ObservadoresInterfaz obs)
	{
		lista.add(obs);
		return "Observador agregado!";
	}
	
	@Override
	public String eliminar(ObservadoresInterfaz obs)
	{
		lista.remove(obs);
		return "Observador eliminado!";
	}
	
	@Override
	public String notificar()
	{
		String salida = "";
		
		for(ObservadoresInterfaz obs: lista)
		{
			salida += obs.actualizacion();
		}
		
		return salida;
	}

	public String getUltimaPosicion() {
		return ultimaPosicion;
	}

	public String setUltimaPosicion(String ultimaPosicion) 
	{
		this.ultimaPosicion = ultimaPosicion;
		
		return notificar();
	}
	
	
}
