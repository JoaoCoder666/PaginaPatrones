package co.edu.udistrital.model.abstracto;

public interface UbicacionInterfaz {
	public String agregar(ObservadoresInterfaz obs);
	public String eliminar(ObservadoresInterfaz obs);
	public String notificar();
}
