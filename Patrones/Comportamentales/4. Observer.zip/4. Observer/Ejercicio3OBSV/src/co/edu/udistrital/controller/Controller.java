package co.edu.udistrital.controller;

import co.edu.udistrital.model.Observador;
import co.edu.udistrital.model.Ubicacion;
import co.edu.udistrital.model.abstracto.ObservadoresInterfaz;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		Ubicacion ubicacion = new Ubicacion();
		
		ObservadoresInterfaz obs1 = new Observador(ubicacion, "Observador 1");
		ObservadoresInterfaz obs2 = new Observador(ubicacion, "Observador 2");
		
		ubicacion.agregar(obs1);
		ubicacion.agregar(obs2);
		
		while(true)
		{
			String ultimaP = vista.leerCadenaDeTexto("Ultima actualizacion de la posicion: ");
			
			vista.mostrarInformacion(ubicacion.setUltimaPosicion(ultimaP));
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2. no"));
			
			if(cont == 1)
			{
				cont = 0;
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
