package co.edu.udistrital.model.abstracto;

public interface ObservadoresInterfaz {
	public String actualizacion();
}
