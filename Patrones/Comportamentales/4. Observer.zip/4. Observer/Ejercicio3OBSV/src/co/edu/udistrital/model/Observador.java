package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ObservadoresInterfaz;

public class Observador implements ObservadoresInterfaz{
	private String nombre;
	private Ubicacion ubicacion;
	
	public Observador(Ubicacion ubicacion, String nombre)
	{
		this.nombre = nombre;
		this.ubicacion = ubicacion;
	}
	
	@Override
	public String actualizacion()
	{
		return "\n\u2022 " + this.nombre + ": Ultima actualizacion en: " + this.ubicacion.getUltimaPosicion();
	}
}
