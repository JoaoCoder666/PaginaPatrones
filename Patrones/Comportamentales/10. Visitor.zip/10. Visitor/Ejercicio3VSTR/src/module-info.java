/**
 * 
 */
/**
 * 
 */
module Ejercicio3VSTR {
}