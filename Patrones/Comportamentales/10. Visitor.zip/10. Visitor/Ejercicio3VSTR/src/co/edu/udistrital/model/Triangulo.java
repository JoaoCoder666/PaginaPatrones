package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Figura;
import co.edu.udistrital.model.abstracto.Visitor;

public class Triangulo implements Figura{
	private double base;
	private double altura;
	
	public Triangulo(double b, double a)
	{
		this.base = b;
		this.altura = a;
	}

	@Override
	public String aceptarVisitor(Visitor visitor) {
		return visitor.visitarTriangulo(this);
	}

	@Override
	public double getDimension() {
		return this.base * this.altura;
	}
	
	public double getAltura()
	{
		return this.altura;
	}
	
	public double getBase()
	{
		return this.base;
	}
}
