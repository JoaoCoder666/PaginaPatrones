package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Visitor;

public class VisitorArea implements Visitor{
	
	public VisitorArea() {}

	@Override
	public String visitarCirculo(Circulo circulo) {
		return "\n\u2022 Area para circulo de radio " + circulo.getDimension() + ": " + (Math.pow(circulo.getDimension(), 2) * Math.PI);
	}

	@Override
	public String visitarCuadrado(Cuadrado cuadrado) {
		return "\n\u2022 Area para Cuadrado de lado: " + cuadrado.getDimension() + ": " + (4 * cuadrado.getDimension());
	}

	@Override
	public String visitarTriangulo(Triangulo triangulo) {
		return "\n\u2022 Area para Triangulo de base " + triangulo.getBase() + " y altura " + triangulo.getAltura() + ": " + (triangulo.getDimension() / 2);
	}
}
