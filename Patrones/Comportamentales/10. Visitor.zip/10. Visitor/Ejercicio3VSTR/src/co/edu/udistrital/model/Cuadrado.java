package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Figura;
import co.edu.udistrital.model.abstracto.Visitor;

public class Cuadrado implements Figura{
	private double lado;
	
	public Cuadrado(double l)
	{
		this.lado = l;
	}

	@Override
	public String aceptarVisitor(Visitor visitor) {
		return visitor.visitarCuadrado(this);
	}

	@Override
	public double getDimension() {
		return this.lado;
	}
}