package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Figura;
import co.edu.udistrital.model.abstracto.Visitor;

public class Circulo implements Figura{
	private double radio;
	
	public Circulo(double r)
	{
		this.radio = r;
	}

	@Override
	public String aceptarVisitor(Visitor visitor) {
		return visitor.visitarCirculo(this);
	}

	@Override
	public double getDimension() {
		return this.radio;
	}
}
