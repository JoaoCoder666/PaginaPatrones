package co.edu.udistrital.model.abstracto;

public interface Figura {
	public String aceptarVisitor(Visitor visitor);
	public double getDimension();
}
