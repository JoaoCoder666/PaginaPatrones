package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Circulo;
import co.edu.udistrital.model.Cuadrado;
import co.edu.udistrital.model.Triangulo;

public interface Visitor {
	public String visitarCirculo(Circulo circulo);
	public String visitarCuadrado(Cuadrado cuadrado);
	public String visitarTriangulo(Triangulo triangulo);
}
