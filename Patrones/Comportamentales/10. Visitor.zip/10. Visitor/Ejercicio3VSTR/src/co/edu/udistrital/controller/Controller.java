package co.edu.udistrital.controller;

import co.edu.udistrital.model.Circulo;
import co.edu.udistrital.model.VisitorArea;
import co.edu.udistrital.model.abstracto.Figura;
import co.edu.udistrital.model.abstracto.Visitor;
import co.edu.udistrital.model.Cuadrado;
import co.edu.udistrital.model.Triangulo;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		Visitor visitorArea = new VisitorArea();
		
		Figura circulo = new Circulo(4);
		Figura cuadrado = new Cuadrado(7);
		Figura triangulo = new Triangulo(3, 6);
		
		vista.mostrarInformacion("Calculo de areas: ");
		vista.mostrarInformacion(circulo.aceptarVisitor(visitorArea) + cuadrado.aceptarVisitor(visitorArea) + triangulo.aceptarVisitor(visitorArea));
	}
}
