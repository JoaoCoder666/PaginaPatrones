/**
 * 
 */
/**
 * 
 */
module Ejercicio2VSTR {
}