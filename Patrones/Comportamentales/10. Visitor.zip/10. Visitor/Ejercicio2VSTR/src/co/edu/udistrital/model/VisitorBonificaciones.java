package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Visitor;

public class VisitorBonificaciones implements Visitor{
	
	public VisitorBonificaciones() {}

	@Override
	public String visitarEjecutivo(Ejecutivo ejecutivo) {
		return "\n\u2022 Bonificaciones para " + ejecutivo.getNombre() + ": $" + ejecutivo.getSalario()*0.3;
	}

	@Override
	public String visitarVinculaciuonEspecial(VinculacionEspecial vE) {
		return "\n\u2022 Bonificaciones para " + vE.getNombre() + ": $" + vE.getSalario()*0.1;
	}
}
