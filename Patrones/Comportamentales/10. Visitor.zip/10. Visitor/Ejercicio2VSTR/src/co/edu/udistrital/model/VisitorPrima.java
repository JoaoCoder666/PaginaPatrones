package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Visitor;

public class VisitorPrima implements Visitor{
	
	public VisitorPrima() {}

	@Override
	public String visitarEjecutivo(Ejecutivo ejecutivo) {
		return "\n\u2022 Prima para " + ejecutivo.getNombre() + ": $" + ejecutivo.getSalario()*1.2;
	}

	@Override
	public String visitarVinculaciuonEspecial(VinculacionEspecial vE) {
		return "\n\u2022 Prima para " + vE.getNombre() + ": $" + vE.getSalario()*0.6;
	}
	
}
