package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Ejecutivo;
import co.edu.udistrital.model.VinculacionEspecial;

public interface Visitor {
	public String visitarEjecutivo(Ejecutivo ejecutivo);
	public String visitarVinculaciuonEspecial(VinculacionEspecial vE);
}
