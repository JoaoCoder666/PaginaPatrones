package co.edu.udistrital.controller;

import co.edu.udistrital.model.Ejecutivo;
import co.edu.udistrital.model.VinculacionEspecial;
import co.edu.udistrital.model.VisitorBonificaciones;
import co.edu.udistrital.model.VisitorPrima;
import co.edu.udistrital.model.abstracto.Empleado;
import co.edu.udistrital.model.abstracto.Visitor;
import co.edu.udistrital.view.Vista;

public class Controller {
private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		Visitor visitorP = new VisitorPrima();
		Visitor visitorB = new VisitorBonificaciones();
		
		Empleado empleado1 = new Ejecutivo("Mario", 9000000);
		Empleado empleado2 = new VinculacionEspecial("Jose", 1200000);
		
		vista.mostrarInformacion("Calculo de prima: ");
		vista.mostrarInformacion(empleado1.aceptarVisitor(visitorP) + empleado2.aceptarVisitor(visitorP));
		
		vista.mostrarInformacion("---------------------------------------");
		
		vista.mostrarInformacion("Calculo de Bonificaciones: ");
		vista.mostrarInformacion(empleado1.aceptarVisitor(visitorB) + empleado2.aceptarVisitor(visitorB));
	}
}
