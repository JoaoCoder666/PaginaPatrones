package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Empleado;
import co.edu.udistrital.model.abstracto.Visitor;

public class Ejecutivo implements Empleado{
	private String nombre;
	private double salario;
	
	public Ejecutivo(String nombre, double salario)
	{
		this.nombre = nombre;
		this.salario = salario;
	}

	@Override
	public String aceptarVisitor(Visitor visitor) {
		return visitor.visitarEjecutivo(this);
	}

	@Override
	public double getSalario() {
		return this.salario;
	}

	@Override
	public String getNombre() {
		return this.nombre;
	}	
}
