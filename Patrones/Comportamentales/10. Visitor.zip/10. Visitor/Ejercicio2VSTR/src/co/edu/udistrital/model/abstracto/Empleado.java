package co.edu.udistrital.model.abstracto;

public interface Empleado {
	public String aceptarVisitor(Visitor visitor);
	public double getSalario();
	public String getNombre();
}
