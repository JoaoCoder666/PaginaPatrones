package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Producto;
import co.edu.udistrital.model.abstracto.Visitor;

public class Alimento implements Producto{
	private double precio;
	private String nombre;
	
	public Alimento(double p, String n)
	{
		this.precio = p;
		this.nombre= n;
	}

	@Override
	public String aceptar(Visitor visitor) 
	{
		return visitor.visitarAlimento(this);
	}

	@Override
	public double getPrecio() {
		return this.precio;
	}

	@Override
	public String getNombre() {
		return this.nombre;
	}
	
	
}
