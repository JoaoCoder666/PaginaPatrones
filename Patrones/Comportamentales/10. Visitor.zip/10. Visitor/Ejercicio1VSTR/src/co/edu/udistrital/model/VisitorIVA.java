package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Visitor;

public class VisitorIVA implements Visitor{

	public VisitorIVA() {}
	
	@Override
	public String visitarAlimento(Alimento alimento) 
	{
		double iva = alimento.getPrecio() * 0.05;
		
		return "\n\u2022 IVA de " + alimento.getNombre() + ": $" + iva;
	}

	@Override
	public String visitarElectronico(Electronico electonico) {
		double iva = electonico.getPrecio() * 0.15;
		
		return "\n\u2022 IVA de " + electonico.getNombre() + ": $" + iva;
	}
	
}
