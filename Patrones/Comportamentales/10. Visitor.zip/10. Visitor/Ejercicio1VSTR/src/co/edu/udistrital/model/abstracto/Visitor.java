package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Alimento;
import co.edu.udistrital.model.Electronico;

public interface Visitor {
	public String visitarAlimento(Alimento alimento);
	public String visitarElectronico(Electronico electonico);
}
