package co.edu.udistrital.controller;

import co.edu.udistrital.model.Alimento;
import co.edu.udistrital.model.Electronico;
import co.edu.udistrital.model.VisitorDescuento;
import co.edu.udistrital.model.VisitorIVA;
import co.edu.udistrital.model.abstracto.Producto;
import co.edu.udistrital.model.abstracto.Visitor;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		Visitor visitorIva = new VisitorIVA();
		Visitor vistorDesc = new VisitorDescuento();
		
		Producto prod1 = new Alimento(9000, "Paquete manzanas");
		Producto prod2 = new Alimento(50000, "Milo");
		Producto prod3 = new Electronico(5000000, "Iphone");
		Producto prod4 = new Electronico(300000, "Teclado Gamer");
		
		vista.mostrarInformacion("Calculo de IVA: ");
		vista.mostrarInformacion(prod1.aceptar(visitorIva) + prod2.aceptar(visitorIva) + prod3.aceptar(visitorIva) + prod4.aceptar(visitorIva));
		
		vista.mostrarInformacion("---------------------------------------");
		
		vista.mostrarInformacion("Calculo de Descuentos: ");
		vista.mostrarInformacion(prod1.aceptar(vistorDesc) + prod2.aceptar(vistorDesc) + prod3.aceptar(vistorDesc) + prod4.aceptar(vistorDesc));
	}
}
