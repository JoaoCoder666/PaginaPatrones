package co.edu.udistrital.model.abstracto;

public interface Producto {
	public String aceptar(Visitor visitor);
	public double getPrecio();
	public String getNombre();
}
