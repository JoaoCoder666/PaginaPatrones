package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Visitor;

public class VisitorDescuento implements Visitor{

	public VisitorDescuento() {}
	
	@Override
	public String visitarAlimento(Alimento alimento) 
	{
		double descuento = alimento.getPrecio() * 0.20;
		
		return "\n\u2022 Descuento de " + alimento.getNombre() + ": $" + descuento;
	}

	@Override
	public String visitarElectronico(Electronico electonico) {
		double descuento = electonico.getPrecio() * 0.10;
		
		return "\n\u2022 Descuento de " + electonico.getNombre() + ": $" + descuento;
	}
	

}
