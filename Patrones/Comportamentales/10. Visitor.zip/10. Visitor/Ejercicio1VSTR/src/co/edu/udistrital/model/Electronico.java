package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Producto;
import co.edu.udistrital.model.abstracto.Visitor;

public class Electronico implements Producto{
	private double precio;
	private String nombre;
	
	public Electronico(double p, String n)
	{
		this.precio = p;
		this.nombre= n;
	}

	@Override
	public String aceptar(Visitor visitor) 
	{
		return visitor.visitarElectronico(this);
	}

	@Override
	public double getPrecio() {
		return this.precio;
	}

	@Override
	public String getNombre() {
		return this.nombre;
	}
}
