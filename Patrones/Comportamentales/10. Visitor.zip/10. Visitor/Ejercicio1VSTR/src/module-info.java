/**
 * 
 */
/**
 * 
 */
module Ejercicio1VSTR {
}