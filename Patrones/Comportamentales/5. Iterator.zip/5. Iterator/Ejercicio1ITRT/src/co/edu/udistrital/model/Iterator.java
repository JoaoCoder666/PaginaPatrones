package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.IteratorInterfaz;

public class Iterator implements IteratorInterfaz{
	private Juguete[] juguetes;
	private int posicion;
	
	public Iterator(Juguete[] j)
	{
		this.juguetes = j;
	}
	
	@Override
	public Juguete siguiente()
	{
		return juguetes[posicion++];
	}
	
	@Override
	public boolean haySiguiente()
	{
		return posicion < juguetes.length && juguetes[posicion] != null;
	}
}
