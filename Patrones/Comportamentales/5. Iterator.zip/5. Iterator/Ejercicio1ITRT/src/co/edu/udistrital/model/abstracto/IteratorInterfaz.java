package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Juguete;

public interface IteratorInterfaz {
	public Juguete siguiente();
	public boolean haySiguiente();
}
