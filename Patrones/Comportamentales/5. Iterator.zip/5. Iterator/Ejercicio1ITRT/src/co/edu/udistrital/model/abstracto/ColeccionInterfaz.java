package co.edu.udistrital.model.abstracto;

public interface ColeccionInterfaz {
	public IteratorInterfaz crearIterator();
}
