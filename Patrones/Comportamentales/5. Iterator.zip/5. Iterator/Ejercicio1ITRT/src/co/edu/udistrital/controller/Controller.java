package co.edu.udistrital.controller;

import co.edu.udistrital.model.Coleccion;
import co.edu.udistrital.model.Juguete;
import co.edu.udistrital.model.abstracto.IteratorInterfaz;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		int size = Integer.parseInt(vista.leerCadenaDeTexto("Ingrese el tamaño de la colección: "));
		
		String nombre = "";
		Juguete juguete;
		Coleccion coleccion = new Coleccion(size);
		IteratorInterfaz iterador = coleccion.crearIterator();
		
		for(int i = 0; i < size; i++)
		{
			nombre = vista.leerCadenaDeTexto("Ingrese el nombre del " + (i+1) + " juguete: ");
			juguete = new Juguete(nombre);
			
			coleccion.agregarJuguete(juguete);
		}
		
		vista.mostrarInformacion("----------Lista de juguetes----------");
		
		while(iterador.haySiguiente())
		{
			vista.mostrarInformacion("\n\u2022" + iterador.siguiente().toString());
		}
	}
}
