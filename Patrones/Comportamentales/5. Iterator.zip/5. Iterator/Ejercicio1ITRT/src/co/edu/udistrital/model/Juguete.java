package co.edu.udistrital.model;

public class Juguete {
	private String nombre;
	
	public Juguete(String nombre)
	{
		this.nombre = nombre;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	
	@Override
	public String toString()
	{
		return "Juguete: " + this.nombre;
	}
}
