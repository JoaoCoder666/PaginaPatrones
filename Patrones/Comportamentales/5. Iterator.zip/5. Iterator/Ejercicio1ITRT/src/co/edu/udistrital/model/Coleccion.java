package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ColeccionInterfaz;
import co.edu.udistrital.model.abstracto.IteratorInterfaz;

public class Coleccion implements ColeccionInterfaz{
	private Juguete[] juguetes;
	private int indice;
	
	public Coleccion(int ind)
	{
		juguetes = new Juguete[ind];
	}
	
	public void agregarJuguete(Juguete j)
	{
		if(indice < juguetes.length)
		{
			juguetes[indice++] = j; 
		}
	}
	
	public IteratorInterfaz crearIterator()
	{
		return new Iterator(juguetes);
	}
}

