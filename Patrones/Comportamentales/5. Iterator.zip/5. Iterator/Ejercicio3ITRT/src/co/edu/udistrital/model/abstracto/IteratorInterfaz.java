package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Libro;

public interface IteratorInterfaz {
	public Libro siguiente();
	public boolean haySiguiente();
}
