package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ColeccionInterfaz;
import co.edu.udistrital.model.abstracto.IteratorInterfaz;

public class Coleccion implements ColeccionInterfaz{
	private Libro[] libros;
	private int indice;
	
	public Coleccion(int ind)
	{
		libros = new Libro[ind];
	}
	
	public void agregarJuguete(Libro l)
	{
		if(indice < libros.length)
		{
			libros[indice++] = l; 
		}
	}
	
	public IteratorInterfaz crearIterator()
	{
		return new Iterator(libros);
	}

}
