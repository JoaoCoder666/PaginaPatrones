package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.IteratorInterfaz;

public class Iterator implements IteratorInterfaz{
	private Libro[] libros;
	private int posicion;
	
	public Iterator(Libro[] l)
	{
		this.libros = l;
	}
	
	@Override
	public Libro siguiente()
	{
		return libros[posicion++];
	}
	
	@Override
	public boolean haySiguiente()
	{
		return posicion < libros.length && libros[posicion] != null;
	}
}
