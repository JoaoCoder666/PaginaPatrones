package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ColeccionInterfaz;
import co.edu.udistrital.model.abstracto.IteratorInterfaz;

public class Coleccion implements ColeccionInterfaz{
	private Instrumento[] instrumentos;
	private int indice;
	
	public Coleccion(int ind)
	{
		instrumentos = new Instrumento[ind];
	}
	
	public void agregarJuguete(Instrumento i)
	{
		if(indice < instrumentos.length)
		{
			instrumentos[indice++] = i; 
		}
	}
	
	public IteratorInterfaz crearIterator()
	{
		return new Iterator(instrumentos);
	}

}
