package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.IteratorInterfaz;

public class Iterator implements IteratorInterfaz{
	private Instrumento[] instrumentos;
	private int posicion;
	
	public Iterator(Instrumento[] j)
	{
		this.instrumentos = j;
	}
	
	@Override
	public Instrumento siguiente()
	{
		return instrumentos[posicion++];
	}
	
	@Override
	public boolean haySiguiente()
	{
		return posicion < instrumentos.length && instrumentos[posicion] != null;
	}
}
