package co.edu.udistrital.controller;

import co.edu.udistrital.model.Coleccion;
import co.edu.udistrital.model.Instrumento;
import co.edu.udistrital.model.abstracto.IteratorInterfaz;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		int size = Integer.parseInt(vista.leerCadenaDeTexto("Ingrese el tamaño de la colección: "));
		
		String nombre = "";
		Instrumento instrumento;
		Coleccion coleccion = new Coleccion(size);
		IteratorInterfaz iterador = coleccion.crearIterator();
		
		for(int i = 0; i < size; i++)
		{
			nombre = vista.leerCadenaDeTexto("Ingrese el nombre del " + (i+1) + " instrumento: ");
			instrumento = new Instrumento(nombre);
			
			coleccion.agregarJuguete(instrumento);
		}
		
		vista.mostrarInformacion("----------Lista de instrumentos----------");
		
		while(iterador.haySiguiente())
		{
			vista.mostrarInformacion("\n\u2022" + iterador.siguiente().toString());
		}
	}
}
