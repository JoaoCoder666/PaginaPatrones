package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Instrumento;

public interface IteratorInterfaz {
	public Instrumento siguiente();
	public boolean haySiguiente();
}
