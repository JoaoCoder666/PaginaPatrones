package co.edu.udsitrital.model;

public class Cuenta {
	private String estado;
	
	public Cuenta() {}
	
	public void nuevoEstado(String nG)
	{
		this.estado = nG;
	}
	
	public void restaurar(Memento m)
	{
		m.getEstado();
	}
	
	public Memento guardar()
	{
		return new Memento(estado);
	}
}
