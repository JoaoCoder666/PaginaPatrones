package co.edu.udistrital.controller;

import co.edu.udistrital.model.Guardado;
import co.edu.udistrital.model.Pedido;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Estado Pedido Online---");
		
		Pedido pedido = new Pedido();
		Guardado guardados = new Guardado();
		
		pedido.nuevoEstado("en camino");
		guardados.guardarEstados(pedido.guardar());
		
		while(true)
		{
			int cont = 0;
			String nuevoEstado = "";
			
			int opcion = Integer.parseInt(vista.leerCadenaDeTexto("Seleccione una opcion:"
					+ "\n1 \u2022 crear estado"
					+ "\n2 \u2022 ver ultimo estado"
					+ "\n3 \u2022 salir"));
			
			switch(opcion) 
			{
			case 1:
				nuevoEstado = vista.leerCadenaDeTexto("Ingrese el estado: ");
				pedido.nuevoEstado(nuevoEstado);
				guardados.guardarEstados(pedido.guardar());
				
				cont = Integer.parseInt(vista.leerCadenaDeTexto("¿Desea continuar en el programa?"
						+ "\n1. si"
						+ "\n2. no"));
				
				if(cont == 1)
				{
					cont = 0;
					continue;
				}
				else
				{
					vista.mostrarInformacion("¡Gracias por usar el programa!");
					System.exit(0);
				}
			case 2:
				vista.mostrarInformacion("\n\u2022 " + guardados.getultimo());
				
				cont = Integer.parseInt(vista.leerCadenaDeTexto("¿Desea continuar en el programa?"
						+ "\n1. si"
						+ "\n2. no"));
				
				if(cont == 1)
				{
					cont = 0;
					continue;
				}
				else
				{
					vista.mostrarInformacion("¡Gracias por usar el programa!");
					System.exit(0);
				}
			case 3:
				vista.mostrarInformacion("¡Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
	
}
