package co.edu.udistrital.model;

public class Pedido {
	private String estado;
	
	public Pedido() {}
	
	public void nuevoEstado(String nG)
	{
		this.estado = nG;
	}
	
	public void restaurar(Memento m)
	{
		m.getEstado();
	}
	
	public Memento guardar()
	{
		return new Memento(estado);
	}
}
