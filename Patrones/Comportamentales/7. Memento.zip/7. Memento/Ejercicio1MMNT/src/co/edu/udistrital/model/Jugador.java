package co.edu.udistrital.model;

public class Jugador {
	private String guardado;
	
	public Jugador() {}
	
	public void nuevoGuardado(String nG)
	{
		this.guardado = nG;
	}
	
	public void restaurar(Memento m)
	{
		m.getEstado();
	}
	
	public Memento guardar()
	{
		return new Memento(guardado);
	}
}
