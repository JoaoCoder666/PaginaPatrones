package co.edu.udistrital.model;

public class Memento {
	private final String save;
	
	public Memento(String save)
	{
		this.save = save;
	}
	
	public String getEstado()
	{
		return this.save;
	}
}
