package co.edu.udistrital.model;

public class Guardado {
	 private final java.util.Stack<Memento> guardados = new java.util.Stack<>();
	 
	 public Guardado() {}
	 
	 public void guardarEstados(Memento m)
	 {
		 guardados.push(m);
	 }
	 
	 public Memento borrarEstados() 
	 {
	     return guardados.pop();
	 }
	 
	 public String getultimo()
	 {
		 return guardados.getLast().getEstado(); 
	 }
}
