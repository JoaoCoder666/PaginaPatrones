package co.edu.udistrital.controller;

import co.edu.udistrital.model.Guardado;
import co.edu.udistrital.model.Jugador;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Guardados Videojuego---");
		
		Jugador jugador = new Jugador();
		Guardado guardados = new Guardado();
		
		jugador.nuevoGuardado("Base de aparicion");
		guardados.guardarEstados(jugador.guardar());
		
		while(true)
		{
			int cont = 0;
			String nuevoGuardado = "";
			
			int opcion = Integer.parseInt(vista.leerCadenaDeTexto("Seleccione una opcion:"
					+ "\n1 \u2022 crear guardado"
					+ "\n2 \u2022 ver ultimo guardado"
					+ "\n3 \u2022 salir"));
			
			switch(opcion)
			{
			case 1:
				nuevoGuardado = vista.leerCadenaDeTexto("Ingrese la poscion del ultimo guardado");
				jugador.nuevoGuardado(nuevoGuardado);
				guardados.guardarEstados(jugador.guardar());
				
				cont = Integer.parseInt(vista.leerCadenaDeTexto("¿Desea continuar en el programa?"
						+ "\n1. si"
						+ "\n2. no"));
				
				if(cont == 1)
				{
					cont = 0;
					continue;
				}
				else
				{
					vista.mostrarInformacion("¡Gracias por usar el programa!");
					System.exit(0);
				}
			case 2:
				vista.mostrarInformacion("\n\u2022 " + guardados.getultimo());
				
				cont = Integer.parseInt(vista.leerCadenaDeTexto("¿Desea continuar en el programa?"
						+ "\n1. si"
						+ "\n2. no"));
				
				if(cont == 1)
				{
					cont = 0;
					continue;
				}
				else
				{
					vista.mostrarInformacion("¡Gracias por usar el programa!");
					System.exit(0);
				}
			case 3:
				vista.mostrarInformacion("¡Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
