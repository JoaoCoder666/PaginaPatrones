package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ChatMediator;
import co.edu.udistrital.model.abstracto.Usuario;

public class UsuarioConcreto extends Usuario{

	public UsuarioConcreto(ChatMediator mediador, String nombre) 
	{
		super(mediador, nombre);
	}

	@Override
	public String enviar(String mensaje) 
	{
		return mediador.enviarMensaje(mensaje, this);
	}

	@Override
	public String recibir(String mensaje) 
	{
		return this.nombre + " recibe: " + mensaje;
	}
}
