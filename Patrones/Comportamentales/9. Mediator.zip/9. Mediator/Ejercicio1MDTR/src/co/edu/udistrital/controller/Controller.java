package co.edu.udistrital.controller;

import co.edu.udistrital.model.ChatSala;
import co.edu.udistrital.model.UsuarioConcreto;
import co.edu.udistrital.model.abstracto.ChatMediator;
import co.edu.udistrital.model.abstracto.Usuario;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Sala de chat---");
		
		ChatMediator sala = new ChatSala();
		
		Usuario usuario1 = new UsuarioConcreto(sala, "Juan");
		Usuario usuario2 = new UsuarioConcreto(sala, "Vane");
		Usuario usuario3 = new UsuarioConcreto(sala, "David");
		
		sala.registrarUsuario(usuario1);
		sala.registrarUsuario(usuario2);
		sala.registrarUsuario(usuario3);
		
		vista.mostrarInformacion(usuario1.enviar("Hola todos!"));
		vista.mostrarInformacion(usuario2.enviar("Hola!"));
		vista.mostrarInformacion(usuario3.enviar("Hola!"));
	}
}
