package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ChatMediator;
import co.edu.udistrital.model.abstracto.Usuario;

import java.util.ArrayList;

public class ChatSala implements ChatMediator{
	private ArrayList<Usuario> usuarios = new ArrayList<>();
	
	public ChatSala() {}
	
	@Override
	public String  enviarMensaje(String mensaje, Usuario remitente) 
	{
		String salida = "";
		
		for (Usuario usuario : usuarios) 
		{
            if (usuario != remitente) 
            {
                salida += "\n\u2022 " +usuario.recibir("De " + remitente.getNombre() + ": " + mensaje);
            }
        }
		
		return salida;
	}

	@Override
	public void registrarUsuario(Usuario usuario) 
	{
		usuarios.add(usuario);
	}
}
