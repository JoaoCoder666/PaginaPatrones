package co.edu.udistrital.model.abstracto;

public interface ChatMediator {
	 public String enviarMensaje(String mensaje, Usuario usuario);
	 public void registrarUsuario(Usuario usuario);
}
