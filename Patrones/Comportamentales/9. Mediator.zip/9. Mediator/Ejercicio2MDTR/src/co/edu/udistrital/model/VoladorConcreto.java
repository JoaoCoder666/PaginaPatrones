package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.TorreMediator;
import co.edu.udistrital.model.abstracto.Volador;

public class VoladorConcreto  extends Volador{

	public VoladorConcreto(TorreMediator mediador, String nombre) 
	{
		super(mediador, nombre);
	}

	@Override
	public String enviar(String mensaje) 
	{
		return mediador.enviarMensaje(mensaje, this);
	}

	@Override
	public String recibir(String mensaje) 
	{
		return this.nombre + " recibe: " + mensaje;
	}
}
