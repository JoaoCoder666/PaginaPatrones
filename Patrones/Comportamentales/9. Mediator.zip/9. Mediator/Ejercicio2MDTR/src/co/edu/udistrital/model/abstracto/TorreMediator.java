package co.edu.udistrital.model.abstracto;

public interface TorreMediator {
	 public String enviarMensaje(String mensaje, Volador volador);
	 public void registrarVolador(Volador volador);
}
