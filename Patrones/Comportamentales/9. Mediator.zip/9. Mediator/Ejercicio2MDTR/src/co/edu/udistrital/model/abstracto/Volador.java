package co.edu.udistrital.model.abstracto;

public abstract class Volador {
	protected TorreMediator mediador;
	protected String nombre;
	
	public Volador(TorreMediator mediador, String nombre) {
	     this.mediador = mediador;
	     this.nombre = nombre;
	 }

	 public abstract String enviar(String mensaje);
	 public abstract String recibir(String mensaje);

	 public String getNombre()
	 {
		 return this.nombre;
	 }
}
