package co.edu.udistrital.controller;

import co.edu.udistrital.model.TorreControl;
import co.edu.udistrital.model.VoladorConcreto;
import co.edu.udistrital.model.abstracto.TorreMediator;
import co.edu.udistrital.model.abstracto.Volador;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Sala de chat---");
		
		TorreMediator torre = new TorreControl();
		
		Volador volador1 = new VoladorConcreto(torre, "Avion");
		Volador volador2 = new VoladorConcreto(torre, "Helicoptero");
		Volador volador3 = new VoladorConcreto(torre, "Avioneta");
		
		torre.registrarVolador(volador1);
		torre.registrarVolador(volador2);
		torre.registrarVolador(volador3);
		
		vista.mostrarInformacion(volador1.enviar("Aterrizando en la salida 2"));
		vista.mostrarInformacion(volador2.enviar("Cambiando punto de aterrizaje a la salida 4"));
		vista.mostrarInformacion(volador3.enviar("No tengo donde aterrizar"));
	}
}
