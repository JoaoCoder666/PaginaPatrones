package co.edu.udistrital.model;

import java.util.ArrayList;

import co.edu.udistrital.model.abstracto.TorreMediator;
import co.edu.udistrital.model.abstracto.Volador;

public class TorreControl implements TorreMediator{
	private ArrayList<Volador> voladores = new ArrayList<>();
	
	public TorreControl() {}
	
	@Override
	public String enviarMensaje(String mensaje, Volador remitente) 
	{
		String salida = "";
		
		for (Volador volador : voladores) 
		{
            if (volador != remitente) 
            {
                salida += "\n\u2022 " + volador.recibir("De " + remitente.getNombre() + ": " + mensaje);
            }
        }
		
		return salida;
	}

	@Override
	public void registrarVolador(Volador volador)
	{
		voladores.add(volador);
	}
}
