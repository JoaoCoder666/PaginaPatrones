package co.edu.udistrital.controller;

import co.edu.udistrital.model.CombateConcreto;
import co.edu.udistrital.model.PeleadorConcreto;
import co.edu.udistrital.model.abstracto.CombateMediator;
import co.edu.udistrital.model.abstracto.Peleador;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Sala de chat---");
	
		CombateMediator combate = new CombateConcreto();
		
		Peleador peleador1 = new PeleadorConcreto(combate, "Scorpion");
		Peleador peleador2 = new PeleadorConcreto(combate, "Sub Zero");
		Peleador peleador3 = new PeleadorConcreto(combate, "El Chapulin Colorado");
		
		combate.registrarPeleador(peleador1);
		combate.registrarPeleador(peleador2);
		combate.registrarPeleador(peleador3);
		
		vista.mostrarInformacion(peleador1.atacar("cadena en llamas"));
		vista.mostrarInformacion(peleador2.atacar("Rayo congelador"));
		vista.mostrarInformacion(peleador3.atacar("Martillo Chillon"));
	}
}
