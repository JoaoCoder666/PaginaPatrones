package co.edu.udistrital.model;

import java.util.ArrayList;

import co.edu.udistrital.model.abstracto.CombateMediator;
import co.edu.udistrital.model.abstracto.Peleador;


public class CombateConcreto implements CombateMediator{
	private ArrayList<Peleador> peleadores = new ArrayList<>();
	
	public CombateConcreto() {}
	
	@Override
	public String enviarAtaque(String ataque, Peleador receptor) 
	{
		String salida = "";
		
		for (Peleador peleador : peleadores) 
		{
            if (peleador != receptor) 
            {
                salida += "\n\u2022 " + peleador.recibir("De " + receptor.getNombre() + ": " + ataque);
            }
        }
		
		return salida;
	}

	@Override
	public void registrarPeleador(Peleador peleador)
	{
		peleadores.add(peleador);
	}

}
