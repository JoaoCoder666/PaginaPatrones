package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.CombateMediator;
import co.edu.udistrital.model.abstracto.Peleador;

public class PeleadorConcreto  extends Peleador{

	public PeleadorConcreto(CombateMediator mediador, String nombre) 
	{
		super(mediador, nombre);
	}

	@Override
	public String atacar(String ataque) 
	{
		return mediador.enviarAtaque(ataque, this);
	}

	@Override
	public String recibir(String mensaje) 
	{
		return this.nombre + " recibe: " + mensaje;
	}

}
