package co.edu.udistrital.model.abstracto;

public abstract class Peleador {
	protected CombateMediator mediador;
	protected String nombre;
	
	public Peleador(CombateMediator mediador, String nombre) {
	     this.mediador = mediador;
	     this.nombre = nombre;
	 }

	 public abstract String atacar(String ataque);
	 public abstract String recibir(String ataque);

	 public String getNombre()
	 {
		 return this.nombre;
	 }
}
