package co.edu.udistrital.model.abstracto;

public interface CombateMediator {
	 public String enviarAtaque(String mensaje, Peleador peleador);
	 public void registrarPeleador(Peleador peleador);
}
