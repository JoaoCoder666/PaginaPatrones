package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Receta;

public class Pasta extends Receta{
	
	public Pasta() {}
	
	@Override
	public String agregarIngredientes() 
	{
		return "\n\u2022 Agregando pasta y sal";
	}

	@Override
	public String cocinar() {
		return "\n\u2022 Cocinando a fuego lento por 10 min...";
	}
	
}
