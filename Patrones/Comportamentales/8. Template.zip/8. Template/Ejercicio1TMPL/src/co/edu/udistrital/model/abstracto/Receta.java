package co.edu.udistrital.model.abstracto;

public abstract class Receta {
	public String preparar()
	{
		String salida = "";
		salida += hervirAgua();
		salida += agregarIngredientes();
		salida += cocinar();
		salida += servir();
		
		return salida;
	}
	
	public String hervirAgua()
	{
		return "\n\u2022 Hirviendo el agua...";
	}
	
	public abstract String agregarIngredientes();
	public abstract String cocinar();
	
	public String servir()
	{
		return "\n\u2022 Sirviendo en el plato";
	}
}
