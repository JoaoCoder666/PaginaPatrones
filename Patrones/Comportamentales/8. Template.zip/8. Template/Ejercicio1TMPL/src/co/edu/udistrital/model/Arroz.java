package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Receta;

public class Arroz extends Receta{

	public Arroz() {}
	
	@Override
	public String agregarIngredientes() {
		return "\n\u2022 Agregando arroz, cebolla, aceite y sal...";
	}

	@Override
	public String cocinar() {
		return "\n\u2022 Cocinando a fuego lento 20 minutos...";
	}
	
}
