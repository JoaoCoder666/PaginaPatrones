package co.edu.udistrital.controller;

import co.edu.udistrital.model.Arroz;
import co.edu.udistrital.model.Pasta;
import co.edu.udistrital.model.abstracto.Receta;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Recetas---");
		
		Receta receta;
		
		vista.mostrarInformacion("Receta 1: ");
		receta = new Arroz();
		vista.mostrarInformacion(receta.preparar());
		
		vista.mostrarInformacion("----------------");
		
		vista.mostrarInformacion("Receta 2: ");
		receta = new Pasta();
		vista.mostrarInformacion(receta.preparar());
	}
}
