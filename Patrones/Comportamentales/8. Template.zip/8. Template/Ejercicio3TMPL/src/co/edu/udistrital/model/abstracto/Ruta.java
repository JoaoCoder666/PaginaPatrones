package co.edu.udistrital.model.abstracto;

public abstract class Ruta {
	
	public String tomarRuta()
	{
		String salida = "";
		
		salida += empezar();
		salida += estrategia();
		salida += llegada();
		
		return salida;
	}
	
	public abstract String empezar();
	public abstract String estrategia();
	
	public String llegada()
	{
		return "\n\u2022 Has llegado a tu destino!";
	}
}
