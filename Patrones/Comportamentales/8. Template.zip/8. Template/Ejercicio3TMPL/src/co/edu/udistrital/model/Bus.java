package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Ruta;

public class Bus extends Ruta{

	public Bus() {}
	
	@Override
	public String empezar() {
		return "\n\u2022 Esperar por la ruta deseada en un paradero del bus...";
	}

	@Override
	public String estrategia() {
		return "\n\u2022 Tratar de tomar asiento si es un trayecto largo, cuidar objetos personales...";
	}
	
}	
