package co.edu.udistrital.controller;

import co.edu.udistrital.model.Bus;
import co.edu.udistrital.model.Caminar;
import co.edu.udistrital.model.Carro;
import co.edu.udistrital.model.abstracto.Ruta;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Guia Rutas---");
		
		Ruta ruta;
		
		vista.mostrarInformacion("Ruta 1: ");
		ruta = new Bus();
		vista.mostrarInformacion(ruta.tomarRuta());
		
		vista.mostrarInformacion("----------------");
		
		vista.mostrarInformacion("Ruta 2: ");
		ruta = new Carro();
		vista.mostrarInformacion(ruta.tomarRuta());
		
		vista.mostrarInformacion("----------------");
		
		vista.mostrarInformacion("Ruta 3: ");
		ruta = new Caminar();
		vista.mostrarInformacion(ruta.tomarRuta());
	}
}
