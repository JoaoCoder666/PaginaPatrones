package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Ruta;

public class Caminar extends Ruta{

	public Caminar() {}
	
	@Override
	public String empezar() {
		return "\n\u2022 Utilizar ropa comoda y salir de casa...";
	}

	@Override
	public String estrategia() {
		return "\n\u2022 Tomar una ruta segura y rapida...";
	}

}
