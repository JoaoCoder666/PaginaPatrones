package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Ruta;

public class Carro extends Ruta{

	public Carro() {}
	
	@Override
	public String empezar() {
		return "\n\u2022 Asegurarse de tener el tanque con gasolina y arrancar...";
	}

	@Override
	public String estrategia() {
		return "\n\u2022 Manejar siguiendo las normas de transito por la ruta mas adecuada...";
	}

}
