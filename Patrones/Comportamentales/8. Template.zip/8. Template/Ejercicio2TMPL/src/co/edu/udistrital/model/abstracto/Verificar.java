package co.edu.udistrital.model.abstracto;

public abstract class Verificar {
	public String verificarLogin()
	{
		String salida = "";
		
		salida += usuario();
		salida += correo();
		salida += area();
		salida += bienvenida();
		
		return salida;
	}
	
	public String usuario()
	{
		return "\n\u2022 Verificando Usuario...";
	}
	
	public abstract String correo();
	public abstract	String area();
	
	public String bienvenida()
	{
		return "\n\u2022 Bienvenido a nuestra comunidad!";
	}
}
