package co.edu.udistrital.controller;

import co.edu.udistrital.model.Cliente;
import co.edu.udistrital.model.Empresa;
import co.edu.udistrital.model.abstracto.Verificar;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Login---");
		
		Verificar cuenta;
		
		vista.mostrarInformacion("Cuenta 1: ");
		cuenta = new Empresa();
		vista.mostrarInformacion(cuenta.verificarLogin());
		
		vista.mostrarInformacion("----------------");
		
		vista.mostrarInformacion("Cuenta 2: ");
		cuenta = new Cliente();
		vista.mostrarInformacion(cuenta.verificarLogin());
	}
}
