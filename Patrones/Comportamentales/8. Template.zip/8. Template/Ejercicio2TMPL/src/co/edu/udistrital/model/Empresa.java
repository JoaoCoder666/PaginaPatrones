package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Verificar;

public class Empresa extends Verificar{

	public Empresa() {}
	
	@Override
	public String correo() {
		return "\n\u2022 Su Correo es de la empresa...";
	}

	@Override
	public String area() {
		return "\n\u2022 Verificando area a la que pertenece...";
	}

}
