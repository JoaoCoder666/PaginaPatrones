package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Verificar;

public class Cliente extends Verificar{

	public Cliente() {}
	
	@Override
	public String correo() {
		return "\n\u2022 Su Correo no es de la empresa...";
	}

	@Override
	public String area() {
		return "";
	}
}
