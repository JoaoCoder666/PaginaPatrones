package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Handler;
import co.edu.udistrital.model.concreto.SeguridadAvanzada;
import co.edu.udistrital.model.concreto.SeguridadEspecial;
import co.edu.udistrital.model.concreto.SeguridadSencilla;
import co.edu.udistrital.view.Vista;

public class Controller {
private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Demostracion del patron cadena de responsabilidades");
		
		Handler sencilla = new SeguridadSencilla();
		Handler especial = new SeguridadEspecial();
		Handler avanzada = new SeguridadAvanzada();
		
		sencilla.setHandler(especial);
		especial.setHandler(avanzada);
		
		vista.mostrarInformacion("El primer ataque sera: Avanzado");
		sencilla.asegurar("Avanzado");
		
		vista.mostrarInformacion("-----------------------");
		
		vista.mostrarInformacion("El segundo ataque sera: Sencillo");
		sencilla.asegurar("Sencillo");
		
		vista.mostrarInformacion("-----------------------");
		
		vista.mostrarInformacion("El tercer ataque sera: Imparable");
		sencilla.asegurar("Imparable");
	}
}
