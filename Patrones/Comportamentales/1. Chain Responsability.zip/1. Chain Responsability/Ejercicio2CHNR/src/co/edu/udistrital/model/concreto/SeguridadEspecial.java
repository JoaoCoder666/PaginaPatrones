package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Handler;

public class SeguridadEspecial implements Handler{
	private Handler handler;
	
	public SeguridadEspecial() {}
	
	@Override
	public void setHandler(Handler handler)
	{
		this.handler = handler;
	}
	
	@Override
	public void asegurar(String ataque)
	{
		if(ataque.toLowerCase().equals("especial"))
		{
			System.out.println("Ataque: " + ataque + " asegurado exitosamente con la seguridad especial!");
		}
		else if(this.handler != null)
		{
			System.out.println("Imposible defender, pasando a otra seguridad");
			handler.asegurar(ataque);
		}
		else
		{
			System.out.println("Ataque invalido");
		}
	}

}
