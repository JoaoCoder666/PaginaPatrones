package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Handler;

public class HandlerSencillo implements Handler{
	private Handler nextHandler;
	
	public HandlerSencillo() {}
	
	@Override
	public void setHandler(Handler handler)
	{
		this.nextHandler = handler;
	}
	
	@Override
	public void atender(String problema)
	{
		if(problema.toLowerCase().equals("sencillo")) 
		{
			System.out.println("Problema: " + problema + " solucionado correctamente con el solucionador sencillo!\n");
		}
		else if(this.nextHandler != null)
		{
			System.out.println("Imposible solucionar, intentando otro solucionador");
			this.nextHandler.atender(problema);
		}
		else
		{
			System.out.println("Problema invalido");
		}
	}
}
