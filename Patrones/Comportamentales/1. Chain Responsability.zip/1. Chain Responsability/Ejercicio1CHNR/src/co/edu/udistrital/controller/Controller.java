package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Handler;
import co.edu.udistrital.model.concreto.HandlerComplicado;
import co.edu.udistrital.model.concreto.HandlerEspecial;
import co.edu.udistrital.model.concreto.HandlerSencillo;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Demostracion del patron cadena de responsabilidades");
		
		Handler sencillo = new HandlerSencillo();
		Handler especial = new HandlerEspecial();
		Handler complicado = new HandlerComplicado();
		
		sencillo.setHandler(especial);
		especial.setHandler(complicado);
		
		vista.mostrarInformacion("El primer problema sera: complicado");
		sencillo.atender("complicado");
		
		vista.mostrarInformacion("-----------------------");
		
		vista.mostrarInformacion("El segundo problema sera: sencillo");
		sencillo.atender("Sencillo");
		
		vista.mostrarInformacion("-----------------------");
		
		vista.mostrarInformacion("El tercer problema sera: urgente");
		sencillo.atender("urgente");
	}
}
