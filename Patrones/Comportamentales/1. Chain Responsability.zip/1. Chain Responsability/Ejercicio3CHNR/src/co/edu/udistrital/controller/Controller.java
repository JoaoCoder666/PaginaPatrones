package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Handler;
import co.edu.udistrital.model.concreto.FiltroEstafa;
import co.edu.udistrital.model.concreto.FiltroSpam;
import co.edu.udistrital.model.concreto.FiltroVirus;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Demostracion del patron cadena de responsabilidades");
		
		Handler spam = new FiltroSpam();
		Handler estafa = new FiltroEstafa();
		Handler virus = new FiltroVirus();
		
		spam.setHandler(estafa);
		estafa.setHandler(virus);
		
		vista.mostrarInformacion("El primer correo sera: un virus");
		spam.revisar("virus");
		
		vista.mostrarInformacion("-----------------------");
		
		vista.mostrarInformacion("El segundo correo sera: spam");
		spam.revisar("spam");
		
		vista.mostrarInformacion("-----------------------");
		
		vista.mostrarInformacion("El tercer correo sera: phishing");
		spam.revisar("phishing");
	}
}
