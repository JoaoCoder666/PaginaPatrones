package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Handler;

public class FiltroSpam implements Handler{
	private Handler handler;
	
	public FiltroSpam() {}
	
	@Override
	public void setHandler(Handler handler)
	{
		this.handler = handler;
	}
	
	@Override
	public void revisar(String correo)
	{
		if(correo.toLowerCase().equals("spam"))
		{
			System.out.println("Correo detectado como spam eliminado exitosamente!");
		}
		else if(this.handler != null)
		{
			System.out.println("No parece ser un correo con spam, pasando al siguiente filtro");
			this.handler.revisar(correo);
		}
		else
		{
			System.out.println("Amenaza peligrosa, perdiendo acceso a la cuenta");
		}
	}
}
