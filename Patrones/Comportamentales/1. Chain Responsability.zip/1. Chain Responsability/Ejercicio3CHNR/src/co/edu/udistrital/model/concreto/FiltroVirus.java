package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Handler;

public class FiltroVirus implements Handler{
	private Handler handler;
	
	public FiltroVirus() {}
	
	@Override
	public void setHandler(Handler handler)
	{
		this.handler = handler;
	}
	
	@Override
	public void revisar(String correo)
	{
		if(correo.toLowerCase().equals("virus"))
		{
			System.out.println("Correo detectado como virus eliminado exitosamente!");
		}
		else if(this.handler != null)
		{
			System.out.println("No parece ser un correo con un virus, pasando al siguiente filtro");
			this.handler.revisar(correo);
		}
		else
		{
			System.out.println("Amenaza peligrosa, perdiendo acceso a la cuenta");
		}
	}
}
