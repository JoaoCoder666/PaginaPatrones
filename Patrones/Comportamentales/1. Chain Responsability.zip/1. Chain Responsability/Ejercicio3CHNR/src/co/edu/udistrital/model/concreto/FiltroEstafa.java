package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Handler;

public class FiltroEstafa implements Handler{
	private Handler handler;
	
	public FiltroEstafa() {}
	
	@Override
	public void setHandler(Handler handler)
	{
		this.handler = handler;
	}
	
	@Override
	public void revisar(String correo)
	{
		if(correo.toLowerCase().equals("estafa"))
		{
			System.out.println("Correo detectado como estafa eliminado exitosamente!");
		}
		else if(this.handler != null)
		{
			System.out.println("No parece ser un correo con una estafa, pasando al siguiente filtro");
			this.handler.revisar(correo);
		}
		else
		{
			System.out.println("Amenaza peligrosa, perdiendo acceso a la cuenta");
		}
	}

}
