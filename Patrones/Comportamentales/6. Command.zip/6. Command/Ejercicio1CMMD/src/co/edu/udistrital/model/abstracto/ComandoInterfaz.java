package co.edu.udistrital.model.abstracto;

public interface ComandoInterfaz {
	public String ejecutar();
}

