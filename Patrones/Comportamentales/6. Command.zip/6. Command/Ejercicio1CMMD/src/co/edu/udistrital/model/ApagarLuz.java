package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class ApagarLuz implements ComandoInterfaz{
	private Luz luz;
	
	public ApagarLuz(Luz luz)
	{
		this.luz = luz;
	}
	
	@Override
	public String ejecutar()
	{
		return luz.apagar();
	}
}
