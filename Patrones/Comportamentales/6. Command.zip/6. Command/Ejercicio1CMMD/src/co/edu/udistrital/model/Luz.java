package co.edu.udistrital.model;

public class Luz {
	public String encender()
	{
		return "\u2022Luz encendida\n";
	}
	
	public String apagar()
	{
		return "\u2022Luz apagada\n";
	}
}
