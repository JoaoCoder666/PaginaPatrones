package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class Interruptor {
	private ComandoInterfaz comando;
	
	public Interruptor() {}
	
	public void setComando(ComandoInterfaz comando)
	{
		this.comando = comando;
	}
	
	public String presionar()
	{
		return comando.ejecutar();
	}
}
