package co.edu.udistrital.controller;

import co.edu.udistrital.model.ApagarLuz;
import co.edu.udistrital.model.EncenderLuz;
import co.edu.udistrital.model.Interruptor;
import co.edu.udistrital.model.Luz;
import co.edu.udistrital.model.abstracto.ComandoInterfaz;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Simular comportamiento de un interruptor");
		vista.mostrarInformacion("----------------------------------------");
		
		Luz luz = new Luz();
		ComandoInterfaz comando;
		
		Interruptor interruptor = new Interruptor();
		
		//encender
		comando = new EncenderLuz(luz);
		interruptor.setComando(comando);
		vista.mostrarInformacion(interruptor.presionar());
		
		//apagar
		comando = new ApagarLuz(luz);
		interruptor.setComando(comando);
		vista.mostrarInformacion(interruptor.presionar());
	}
}
