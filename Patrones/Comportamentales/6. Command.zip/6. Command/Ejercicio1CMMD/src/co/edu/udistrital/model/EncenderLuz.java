package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class EncenderLuz implements ComandoInterfaz{
	private Luz luz;
	
	public EncenderLuz(Luz luz)
	{
		this.luz = luz;
	}
	
	@Override
	public String ejecutar()
	{
		return luz.encender();
	}

}
