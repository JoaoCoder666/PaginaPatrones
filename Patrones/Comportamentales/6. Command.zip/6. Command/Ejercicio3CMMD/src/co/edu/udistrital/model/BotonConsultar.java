package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class BotonConsultar {
	private ComandoInterfaz comando;
	
	public BotonConsultar() {}
	
	public void setComando(ComandoInterfaz comando)
	{
		this.comando = comando;
	}
	
	public String consultar()
	{
		return this.comando.ejecutar();
	}
}
