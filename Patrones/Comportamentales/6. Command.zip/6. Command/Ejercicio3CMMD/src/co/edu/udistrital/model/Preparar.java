package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class Preparar implements ComandoInterfaz{
	private Pedido pedido;
	
	public Preparar(Pedido pedido)
	{
		this.pedido = pedido;
	}
	
	@Override
	public String ejecutar()
	{
		return this.pedido.prepararOrden();
	}

}
