package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class Entregar implements ComandoInterfaz{
	private Pedido pedido;
	
	public Entregar(Pedido pedido)
	{
		this.pedido = pedido;
	}
	
	@Override
	public String ejecutar()
	{
		return this.pedido.entregarOrden();
	}
}
