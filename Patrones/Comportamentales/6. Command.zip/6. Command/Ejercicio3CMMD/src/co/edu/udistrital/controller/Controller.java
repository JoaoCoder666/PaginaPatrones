package co.edu.udistrital.controller;

import co.edu.udistrital.model.BotonConsultar;
import co.edu.udistrital.model.Crear;
import co.edu.udistrital.model.Entregar;
import co.edu.udistrital.model.Pedido;
import co.edu.udistrital.model.Preparar;
import co.edu.udistrital.model.abstracto.ComandoInterfaz;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Simular comportamiento de un interruptor");
		vista.mostrarInformacion("----------------------------------------");
		
		Pedido pedido = new Pedido();
		ComandoInterfaz comando;
		
		BotonConsultar boton = new BotonConsultar();
		
		//creando
		comando = new Crear(pedido);
		boton.setComando(comando);
		vista.mostrarInformacion(boton.consultar());
		
		//preparando
		comando = new Preparar(pedido);
		boton.setComando(comando);
		vista.mostrarInformacion(boton.consultar());
		
		//entregado
		comando = new Entregar(pedido);
		boton.setComando(comando);
		vista.mostrarInformacion(boton.consultar());
	}
}
