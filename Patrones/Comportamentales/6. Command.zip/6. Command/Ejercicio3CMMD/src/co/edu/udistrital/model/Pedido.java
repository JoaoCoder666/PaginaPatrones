package co.edu.udistrital.model;

public class Pedido {
	public String crearOrden()
	{
		return "Creando el pedido";
	}
	
	public String prepararOrden()
	{
		return "Preparando el pedido";
	}
	
	public String entregarOrden()
	{
		return "El pedido ha sido entregada";
	}
}
