package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class Crear implements ComandoInterfaz{
	private Pedido pedido;
	
	public Crear(Pedido pedido)
	{
		this.pedido = pedido;
	}
	
	@Override
	public String ejecutar()
	{
		return this.pedido.crearOrden();
	}
}
