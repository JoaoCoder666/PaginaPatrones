package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class SistemaClaro implements ComandoInterfaz{
	private ModoSistema modo;
	
	public SistemaClaro(ModoSistema modo)
	{
		this.modo = modo;
	}
	
	@Override
	public String ejecutar()
	{
		return modo.setClaro();
	}
}
