package co.edu.udistrital.model;

public class ModoSistema {
	public String setOscuro()
	{
		return "El sistema esta en modo oscuro";
	}
	
	public String setClaro()
	{
		return "El sistema esta en modo claro";
	}
}
