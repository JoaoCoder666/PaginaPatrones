package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class SistemaOscuro implements ComandoInterfaz{
	private ModoSistema modo;
	
	public SistemaOscuro(ModoSistema modo)
	{
		this.modo = modo;
	}
	
	@Override
	public String ejecutar()
	{
		return modo.setOscuro();
	}

}
