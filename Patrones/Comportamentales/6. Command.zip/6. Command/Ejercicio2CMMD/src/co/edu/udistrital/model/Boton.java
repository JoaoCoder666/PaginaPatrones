package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.ComandoInterfaz;

public class Boton {
	private ComandoInterfaz comando;
	
	public Boton(){}
	
	public void setComando(ComandoInterfaz comando)
	{
		this.comando = comando;
	}
	
	public String presionar()
	{
		return comando.ejecutar();
	}
}
