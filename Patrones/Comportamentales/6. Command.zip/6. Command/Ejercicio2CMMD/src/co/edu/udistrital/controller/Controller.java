package co.edu.udistrital.controller;

import co.edu.udistrital.model.Boton;
import co.edu.udistrital.model.ModoSistema;
import co.edu.udistrital.model.SistemaClaro;
import co.edu.udistrital.model.SistemaOscuro;
import co.edu.udistrital.model.abstracto.ComandoInterfaz;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Simular comportamiento de un interruptor");
		vista.mostrarInformacion("----------------------------------------");
		
		ModoSistema modo = new ModoSistema();		
		ComandoInterfaz comando;
		
		Boton boton = new Boton();
		
		//claro
		comando = new SistemaClaro(modo);
		boton.setComando(comando);
		vista.mostrarInformacion(boton.presionar());
		
		comando = new SistemaOscuro(modo);
		boton.setComando(comando);
		vista.mostrarInformacion(boton.presionar());
	}
}
