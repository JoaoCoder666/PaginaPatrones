package co.edu.udistrital.model.facade;

import co.edu.udistrital.model.Bateria;
import co.edu.udistrital.model.Carro;
import co.edu.udistrital.model.Motor;

public class FacadeArrancar {
	public boolean Arrancar(Carro c)
	{
		if(new Motor().verifMotor(c) &&  new Bateria().verifBateria(c))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
