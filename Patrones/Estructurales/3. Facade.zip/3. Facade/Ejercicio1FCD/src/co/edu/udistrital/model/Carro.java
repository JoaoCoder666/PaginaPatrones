package co.edu.udistrital.model;

public class Carro {
	private float gasolina;
	private float nivelBateria;
	
	public Carro(float g, float nB)
	{
		this.gasolina = g;
		this.nivelBateria = nB;
	}
	
	public float getGasolina() {
		return gasolina;
	}

	public void setGasolina(float gasolina) {
		this.gasolina = gasolina;
	}

	public float getNivelBateria() {
		return nivelBateria;
	}

	public void setNivelBateria(float nivelBateria) {
		this.nivelBateria = nivelBateria;
	}
	
	@Override
	public String toString()
	{
		return "El cliente tiene: gasolina: " + this.gasolina + ", nivel de bateria: " + this.nivelBateria;
	}
}
