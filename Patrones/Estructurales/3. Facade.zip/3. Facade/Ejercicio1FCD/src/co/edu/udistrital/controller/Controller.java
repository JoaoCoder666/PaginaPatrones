package co.edu.udistrital.controller;

import co.edu.udistrital.model.Carro;
import co.edu.udistrital.model.facade.FacadeArrancar;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		float gasolina = 0;
		float nivelBateria = 0;
		int decision = 0;
		
		vista.mostrarInformacion("---Sistema de arrancado de un vehiculo---");
		
		while(true)
		{
			vista.mostrarInformacion("Ingrese los valores de: ");
			gasolina = Float.parseFloat(vista.leerCadenaDeTexto("Nivel de gasolina: "));
			nivelBateria = Float.parseFloat(vista.leerCadenaDeTexto("Nivel de la bateria: "));
			
			Carro c = new Carro(gasolina, nivelBateria);
			vista.mostrarInformacion(c.toString());
			
			boolean arranca = new FacadeArrancar().Arrancar(c);
			
			if(arranca)
			{
				vista.mostrarInformacion("El vehiculo arranca");
			}
			else
			{
				vista.mostrarInformacion("El vehiculo no es capaz de arrancar");
			}
			
			decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea:"
					+ "\n1. Continuar en el programa"
					+ "\n2. Salir "));
			
			if(decision == 2)
			{
				vista.mostrarInformacion("Gracias por usar el programa");
				System.exit(0);
			}
		}
	}
}
