package co.edu.udistrital.model;

public class Motor {
	public boolean verifMotor(Carro c)
	{
		if(c.getGasolina() < 10 || c.getGasolina() > 100)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
