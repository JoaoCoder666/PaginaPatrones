package co.edu.udistrital.model;

public class Bateria {
	public boolean verifBateria(Carro c)
	{
		if(c.getNivelBateria() < 10 || c.getNivelBateria() > 100)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
