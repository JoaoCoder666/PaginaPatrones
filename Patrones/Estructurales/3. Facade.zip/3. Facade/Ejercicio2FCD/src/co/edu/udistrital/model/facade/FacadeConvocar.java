package co.edu.udistrital.model.facade;

import co.edu.udistrital.model.CuerpoTecnico;
import co.edu.udistrital.model.Equipo;
import co.edu.udistrital.model.Jugadores;

public class FacadeConvocar {
	public boolean convocar(Equipo e)
	{
		if(new Jugadores().verifJugadores(e) && new CuerpoTecnico().verifCuerpoTecnico(e))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
