package co.edu.udistrital.model;

public class CuerpoTecnico {
	public boolean verifCuerpoTecnico(Equipo e)
	{
		if(e.getCantCuerpoTecnico() < 5 || e.getCantCuerpoTecnico() > 20)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
