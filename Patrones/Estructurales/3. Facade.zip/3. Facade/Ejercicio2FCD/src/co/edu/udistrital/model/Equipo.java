package co.edu.udistrital.model;

public class Equipo {
	private int cantJugadores;
	private int cantCuerpoTecnico;
	
	public Equipo(int cJ, int cCT)
	{
		this.cantJugadores = cJ;
		this.cantCuerpoTecnico = cCT;
	}

	public int getCantJugadores() {
		return cantJugadores;
	}

	public void setCantJugadores(int cantJugadores) {
		this.cantJugadores = cantJugadores;
	}

	public int getCantCuerpoTecnico() {
		return cantCuerpoTecnico;
	}

	public void setCantCuerpoTecnico(int cantCuerpoTecnico) {
		this.cantCuerpoTecnico = cantCuerpoTecnico;
	}
	
	@Override
	public String toString()
	{
		return "Equipo: jugadores: " + this.cantJugadores + ", cuerpo tecnico: " + this.cantCuerpoTecnico;
	}
}
