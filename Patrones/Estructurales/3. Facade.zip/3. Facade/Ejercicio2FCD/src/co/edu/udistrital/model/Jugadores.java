package co.edu.udistrital.model;

public class Jugadores {
	public boolean verifJugadores(Equipo e)
	{
		if(e.getCantJugadores() < 22 || e.getCantJugadores() > 26)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
