package co.edu.udistrital.controller;

import co.edu.udistrital.model.Equipo;
import co.edu.udistrital.model.facade.FacadeConvocar;
import co.edu.udistrital.view.Vista;

public class Controller {
private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		int cantJugadores = 0;
		int cantCuerpoTecnico = 0;
		int decision = 0;
		
		vista.mostrarInformacion("---Convocatoria partido de futbol---");
		while(true)
		{
			cantJugadores = Integer.parseInt(vista.leerCadenaDeTexto("Ingrese la cantidad de jugadores: "));
			cantCuerpoTecnico = Integer.parseInt(vista.leerCadenaDeTexto("Ingrese la cantidad de miembros del cuerpo tecnico: "));
			
			Equipo e = new Equipo(cantJugadores, cantCuerpoTecnico);
			vista.mostrarInformacion("------"
					+ "\n" + e.toString() + "\n"
					+ "------");
			
			boolean convocar = new FacadeConvocar().convocar(e);
			
			if(convocar)
			{
				vista.mostrarInformacion("El equipo puede asistir al partido");
			}
			else
			{
				vista.mostrarInformacion("El equipo no puede asistir al partido");
			}
			
			decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea:"
					+ "\n1. Continuar en el programa"
					+ "\n2. Salir "));
			
			if(decision == 2)
			{
				vista.mostrarInformacion("Gracias por usar el programa");
				System.exit(0);
			}
		}
	}
}
