package co.edu.udistrital.model;

public class Experiencia {
	public boolean verifExperiencia(Jugador j)
	{
		if(j.getEstatura() < 3)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
