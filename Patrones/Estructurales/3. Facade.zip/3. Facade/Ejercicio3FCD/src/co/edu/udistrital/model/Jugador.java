package co.edu.udistrital.model;

public class Jugador {
	private float estatura;
	private int experiencia;
	
	public Jugador(float est, int exp)
	{
		this.estatura = est;
		this.experiencia = exp;
	}

	public float getEstatura() {
		return estatura;
	}

	public void setEstatura(float estatura) {
		this.estatura = estatura;
	}

	public int getExperiencia() {
		return experiencia;
	}

	public void setExperiencia(int experiencia) {
		this.experiencia = experiencia;
	}
	
	@Override
	public String toString()
	{
		return "Jugador: "
				+ "\nEstatura:" + this.estatura
				+ "\nExperiencia: " + this.experiencia;
	}
}
