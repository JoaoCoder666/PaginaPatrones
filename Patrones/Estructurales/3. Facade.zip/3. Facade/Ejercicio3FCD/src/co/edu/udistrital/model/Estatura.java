package co.edu.udistrital.model;

public class Estatura {
	public boolean verifEstatura(Jugador j)
	{
		if(j.getEstatura() < 1.88)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
}
