package co.edu.udistrital.controller;

import co.edu.udistrital.model.facade.FacadeReclutar;
import co.edu.udistrital.model.Jugador;
import co.edu.udistrital.view.Vista;

public class Controller {
private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		float estatura = 0;
		int experiencia = 0;
		int decision = 0;
		
		vista.mostrarInformacion("---Reclutar jugador de baloncesto---");
		while(true)
		{
			estatura = Float.parseFloat(vista.leerCadenaDeTexto("Estatura del jugador: "));
			experiencia = Integer.parseInt(vista.leerCadenaDeTexto("años de experiencia del jugador: "));
			
			Jugador j = new Jugador(estatura, experiencia);
			vista.mostrarInformacion(j.toString());
			
			boolean reclutar = new FacadeReclutar().reclutar(j);
			if(reclutar)
			{
				vista.mostrarInformacion("El jugador es optimo para ser reclutado");
			}
			else
			{
				vista.mostrarInformacion("El jugador no seria una buena opcion para reclutar");
			}
			
			decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea:"
					+ "\n1. Continuar en el programa"
					+ "\n2. Salir "));
			
			if(decision == 2)
			{
				vista.mostrarInformacion("Gracias por usar el programa");
				System.exit(0);
			}
		}
	}
}
