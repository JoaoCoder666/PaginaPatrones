package co.edu.udistrital.model.facade;

import co.edu.udistrital.model.Estatura;
import co.edu.udistrital.model.Experiencia;
import co.edu.udistrital.model.Jugador;

public class FacadeReclutar {
	public boolean reclutar(Jugador j)
	{
		if(new Estatura().verifEstatura(j) && new Experiencia().verifExperiencia(j))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
