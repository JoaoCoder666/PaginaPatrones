package co.edu.udistrital.model.compuestos;

public class PlatoSeco extends Compuesto{
	
	public PlatoSeco(String nom)
	{
		this.nombre = nom;
	}
}
