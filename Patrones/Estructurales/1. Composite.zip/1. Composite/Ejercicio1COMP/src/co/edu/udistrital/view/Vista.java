package co.edu.udistrital.view;

import java.util.Scanner;

public class Vista {
	private Scanner sc;
	
	public Vista()
	{
		sc = new Scanner(System.in);
	}
	
	public void mostrarInformacion(String mensaje)
	{
		System.out.println(mensaje);
	}
	
	public String leerCadenaDeTexto(String mensaje)
	{
		System.out.println(mensaje);
		return sc.nextLine();
	}
}
