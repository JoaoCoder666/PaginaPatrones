package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Pedido;
import co.edu.udistrital.model.compuestos.PlatoSeco;
import co.edu.udistrital.model.compuestos.PlatoSopa;
import co.edu.udistrital.model.hojas.Adicion;
import co.edu.udistrital.model.hojas.Proteina;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Menu para crear pedidos");
		while(true)
		{
			int decision = 0;
			int decisionAdicion = 1;
			
			String nombre = "";
			Pedido platoSeco;
			Pedido platoSopa;
			Proteina proteina;
			Adicion adicion;
			
			decision = Integer.parseInt(vista.leerCadenaDeTexto("Seleccione una opcion: "
						+ "\n1.Pedir plato seco"
						+ "\n2.Pedir sopa"
						+ "\n3.salir"));
			
			switch(decision)
			{
			case 1:
				nombre = vista.leerCadenaDeTexto("Ingrese el nombre del plato: ");

				platoSeco = new PlatoSeco(nombre);
				proteina = new Proteina(vista.leerCadenaDeTexto("Ingrese la proteina para el plato: "), 15000);
				platoSeco.agregar(proteina);
				
				
				decisionAdicion = Integer.parseInt(vista.leerCadenaDeTexto("Desea agregar algo mas?"
						+ "\n1.si"
						+ "\n2.no"));
				
				if(decisionAdicion == 1)
				{
					adicion = new Adicion(vista.leerCadenaDeTexto("ingrese la adicion: "), 3000);
					platoSeco.agregar(adicion);
				}
				
				vista.mostrarInformacion("Precio: " + platoSeco.getPrecio());
				vista.mostrarInformacion("Plato Seco: ");
				platoSeco.imprimirOrden();

				decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea: "
						+ "\n1.Hacer otro pedido"
						+ "\n2.salir"));
				
				if(decision == 1)
				{
					decision = 0;
					continue;
				}
				else if(decision == 2)
				{
					vista.mostrarInformacion("Gracias por usar el programa!");
					System.exit(0);
				}
			case 2:
				nombre = vista.leerCadenaDeTexto("Ingrese el nombre del plato: ");

				platoSopa = new PlatoSopa(nombre);
				proteina = new Proteina(vista.leerCadenaDeTexto("Ingrese la proteina para el plato: "), 15000);
				platoSopa.agregar(proteina);
				
				
				decisionAdicion = Integer.parseInt(vista.leerCadenaDeTexto("Desea agregar algo mas?"
						+ "\n1.si"
						+ "\n2.no"));
				
				if(decisionAdicion == 1)
				{
					adicion = new Adicion(vista.leerCadenaDeTexto("ingrese la adicion: "), 3000);
					platoSopa.agregar(adicion);
				}
				
				vista.mostrarInformacion("Precio: " + platoSopa.getPrecio());
				vista.mostrarInformacion("Sopa: ");
				platoSopa.imprimirOrden();
				
				decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea: "
						+ "\n1.Hacer otro pedido"
						+ "\n2.salir"));
				
				if(decision == 1)
				{
					decision = 0;
					continue;
				}
				else if(decision == 2)
				{
					vista.mostrarInformacion("Gracias por usar el programa!");
					System.exit(0);
				}
			case 3:
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
