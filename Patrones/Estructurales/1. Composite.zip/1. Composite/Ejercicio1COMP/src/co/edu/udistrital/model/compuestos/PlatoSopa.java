package co.edu.udistrital.model.compuestos;

public class PlatoSopa extends Compuesto{
	
	public PlatoSopa(String nom)
	{
		this.nombre = nom;
	}
}
