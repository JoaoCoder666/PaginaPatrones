package co.edu.udistrital.model.compuestos;

import java.util.ArrayList;

import co.edu.udistrital.model.abstracto.Pedido;

public class Compuesto implements Pedido{
	
	String nombre;
	ArrayList<Pedido> lista = new ArrayList<Pedido>();
	
	@Override
	public String getNombre()
	{
		return nombre;
	}

	@Override
	public float getPrecio() {
		float total = 0;
		
		for(Pedido pedido: lista)
		{
			total += pedido.getPrecio();
		}
		return total;
	}

	@Override
	public void agregar(Pedido p) {
		lista.add(p);
	}

	@Override
	public void eliminar(Pedido p) {
		lista.add(p);
	}

	@Override
	public void imprimirOrden() {
		String salida = "";
		
		for(Pedido pedido: lista)
		{
			salida += pedido.getNombre() + ", precio: " + pedido.getPrecio() + "\n";
		}
		
		System.out.println(salida);
	}
	
}
