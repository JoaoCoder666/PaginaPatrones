package co.edu.udistrital.model.abstracto;

public interface Pedido {
	String getNombre();
	float getPrecio();
	void agregar(Pedido p);
	void eliminar(Pedido p);
	void imprimirOrden();
}
