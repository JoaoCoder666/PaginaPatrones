package co.edu.udistrital.model.hojas;

import co.edu.udistrital.model.abstracto.Pedido;

public class Proteina implements Pedido{

	String nombre = "";
	float precio = 0;

	public Proteina(String nombre, float precio)
	{
		this.nombre = nombre;
		this.precio = precio;
	}
	
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public float getPrecio() {
		return precio;
	}

	@Override
	public void agregar(Pedido p) {}
	public void eliminar(Pedido p) {}
	public void imprimirOrden() {}

}
