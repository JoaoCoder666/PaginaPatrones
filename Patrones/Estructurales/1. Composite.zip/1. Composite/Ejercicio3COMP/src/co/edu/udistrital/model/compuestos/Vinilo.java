package co.edu.udistrital.model.compuestos;

public class Vinilo extends Compuesto {

	public Vinilo(String nom)
	{
		this.nombre = nom;
	}
}
