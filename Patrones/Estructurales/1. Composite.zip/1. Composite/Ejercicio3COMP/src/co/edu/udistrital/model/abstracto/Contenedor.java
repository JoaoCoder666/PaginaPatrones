package co.edu.udistrital.model.abstracto;

public interface Contenedor {
	String getNombre();
	float getPrecio();
	void agregar(Contenedor c);
	void eliminar(Contenedor c);
	String imprimirCanciones();
}
