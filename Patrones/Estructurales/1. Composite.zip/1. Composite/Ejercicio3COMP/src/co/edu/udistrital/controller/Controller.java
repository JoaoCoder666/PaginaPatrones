package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Contenedor;
import co.edu.udistrital.model.compuestos.DigitalDisc;
import co.edu.udistrital.model.compuestos.Vinilo;
import co.edu.udistrital.model.hojas.Cancion;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Creador de albums de musica");
		
		int decisiones = 0;
		
		String nombre = "";
		float precio = 0;
		
		Contenedor cd;
		Contenedor vinilo;
		
		Cancion cancion;
		int cantCaniones = 0;
		
		while(true)
		{
			decisiones = Integer.parseInt(vista.leerCadenaDeTexto("Desea: "
					+ "\n1.Crear vinilo"
					+ "\n2.Crear CD"
					+ "\n3.Salir"));
			
			switch(decisiones)
			{
			case 1:
				nombre = vista.leerCadenaDeTexto("Ingrese el nombre del vinilo: ");
				vinilo = new Vinilo(nombre);
				
				
				cantCaniones = Integer.parseInt(vista.leerCadenaDeTexto("Cuantas canciones tiene el album"));
				for(int i = 0; i<cantCaniones; i++)
				{
					nombre = vista.leerCadenaDeTexto("Nombre de la " + (i+1) + " cancion");
					precio = Integer.parseInt(vista.leerCadenaDeTexto("precio de la " + (i+1) + " cancion"));
					
					cancion = new Cancion(nombre, precio);
					vinilo.agregar(cancion);
				}
				
				vista.mostrarInformacion("Precio neto: " + vinilo.getPrecio());
				vista.mostrarInformacion("Vinilo: \n" + vinilo.imprimirCanciones());
				
				decisiones = Integer.parseInt(vista.leerCadenaDeTexto("Desea: "
						+ "\n1.hacer otro album"
						+ "\n2.salir"));
				
				if(decisiones == 1)
				{
					decisiones = 0;
					continue;
				}
				else if(decisiones == 2)
				{
					vista.mostrarInformacion("Gracias por usar el programa!");
					System.exit(0);
				}
				
			case 2:
				nombre = vista.leerCadenaDeTexto("Ingrese el nombre del vinilo: ");
				cd = new DigitalDisc(nombre);
				
				
				cantCaniones = Integer.parseInt(vista.leerCadenaDeTexto("Cuantas canciones tiene el album"));
				for(int i = 0; i<cantCaniones; i++)
				{
					nombre = vista.leerCadenaDeTexto("Nombre de la " + (i+1) + " cancion");
					precio = Integer.parseInt(vista.leerCadenaDeTexto("precio de la " + (i+1) + " cancion"));
					
					cancion = new Cancion(nombre, precio);
					cd.agregar(cancion);
				}
				
				vista.mostrarInformacion("Precio neto: " + cd.getPrecio());
				vista.mostrarInformacion("CD: \n" + cd.imprimirCanciones());
				
				decisiones = Integer.parseInt(vista.leerCadenaDeTexto("Desea: "
						+ "\n1.hacer otro album"
						+ "\n2.salir"));
				
				if(decisiones == 1)
				{
					decisiones = 0;
					continue;
				}
				else if(decisiones == 2)
				{
					vista.mostrarInformacion("Gracias por usar el programa!");
					System.exit(0);
				}
			}
		}
	}
}
