package co.edu.udistrital.model.hojas;

import co.edu.udistrital.model.abstracto.Contenedor;

public class Cancion implements Contenedor{

	String nombre;
	float precio;
	
	public Cancion(String nom, float prec)
	{
		this.nombre = nom;
		this.precio = prec;
	}
	
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public float getPrecio() {
		return precio;
	}

	@Override
	public void agregar(Contenedor c) {}
	public void eliminar(Contenedor c) {}
	public String imprimirCanciones() {return "";}

}
