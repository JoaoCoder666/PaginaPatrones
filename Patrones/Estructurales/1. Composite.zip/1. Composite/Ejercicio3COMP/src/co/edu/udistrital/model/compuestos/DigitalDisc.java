package co.edu.udistrital.model.compuestos;

public class DigitalDisc extends Compuesto{

	public DigitalDisc(String nom)
	{
		this.nombre = nom;
	}
}
