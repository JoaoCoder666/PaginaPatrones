package co.edu.udistrital.model.compuestos;

import java.util.ArrayList;

import co.edu.udistrital.model.abstracto.Contenedor;

public class Compuesto implements Contenedor{

	String nombre = "";
	ArrayList<Contenedor> lista = new ArrayList<Contenedor>();
	
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public float getPrecio() {
		float total = 0;
		
		for(Contenedor c: lista)
		{
			total += c.getPrecio();
		}
		
		return total;
	}

	@Override
	public void agregar(Contenedor c) {
		lista.add(c);
	}

	@Override
	public void eliminar(Contenedor c) {
		lista.remove(c);
	}

	@Override
	public String imprimirCanciones() {
		String salida = "";
		
		for(Contenedor c: lista)
		{
			salida += c.getNombre() + "\n";
		}
		
		return salida;
	}
	
}
