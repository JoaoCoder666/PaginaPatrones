package co.edu.udistrital.model.compuestos;

public class PollaGanadora extends Compuesta{
	
	public PollaGanadora(String nom)
	{
		this.nombre = nom;
	}
}
