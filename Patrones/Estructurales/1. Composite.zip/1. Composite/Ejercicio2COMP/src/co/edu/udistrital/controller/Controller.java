package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Apuesta;
import co.edu.udistrital.model.compuestos.PollaGanadora;
import co.edu.udistrital.model.hojas.Secundarias;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Sistema de apuestas");
		
		String nombre = "";
		float precio = 0;
		
		int cantSecundarias = 0;
		int decisionBucle = 0;
		
		Apuesta pollaGanadora;
		Secundarias secundaria;
		
		while(true) 
		{
			nombre = vista.leerCadenaDeTexto("Ingrese los nombre de los equipos(ej: barca vs madrid): ");
			pollaGanadora = new PollaGanadora(nombre);
			
			cantSecundarias = Integer.parseInt(vista.leerCadenaDeTexto("Cuantas apuestas va a hacer?"));
			
			for(int i = 0; i < cantSecundarias; i++)
			{
				nombre = vista.leerCadenaDeTexto("nombre de la " + (i+1) + " apuesta: ");
				precio = Float.parseFloat(vista.leerCadenaDeTexto("valor de la " + (i+1) + " apuesta: "));
				secundaria = new Secundarias(nombre, precio);
				pollaGanadora.agregar(secundaria);
			}
			
			vista.mostrarInformacion("Precio: " + pollaGanadora.getPrecio());
			pollaGanadora.imprimirParley();
			
			decisionBucle = Integer.parseInt(vista.leerCadenaDeTexto("\nDesea: "
					+ "\n1.hacer otra apuesta"
					+ "\n2; salir"));
			
			if(decisionBucle == 2)
			{
				vista.mostrarInformacion("Gracias por usar el programa, suerte!");
				System.exit(0);
			}
		}
		
	}
}
