package co.edu.udistrital.model.compuestos;

import java.util.ArrayList;

import co.edu.udistrital.model.abstracto.Apuesta;

public class Compuesta implements Apuesta{
	
	String nombre;
	ArrayList<Apuesta> lista = new ArrayList<Apuesta>();
	
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public float getPrecio() {
		float total = 0;
		
		for(Apuesta apuesta: lista)
		{
			total += apuesta.getPrecio();
		}
		
		return total;
	}

	@Override
	public void agregar(Apuesta a) {
		lista.add(a);
	}

	@Override
	public void eliminar(Apuesta a) {
		lista.remove(a);
	}

	@Override
	public void imprimirParley() {
		String salida = "";
		
		for(Apuesta apuesta: lista)
		{
			salida += apuesta.getNombre() + " por " + apuesta.getPrecio() + "\n";
		}
		
		System.out.println(salida);
	}
	
}
