package co.edu.udistrital.model.abstracto;

public interface Apuesta {
	String getNombre();
	float getPrecio();
	void agregar(Apuesta a);
	void eliminar(Apuesta a);
	void imprimirParley();
	
}
