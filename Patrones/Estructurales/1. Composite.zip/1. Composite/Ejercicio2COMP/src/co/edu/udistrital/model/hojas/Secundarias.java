package co.edu.udistrital.model.hojas;

import co.edu.udistrital.model.abstracto.Apuesta;

public class Secundarias implements Apuesta{
	String nombre;
	float precio;
	
	public Secundarias(String nom, float prec)
	{
		this.nombre = nom;
		this.precio = prec;
	}
	
	@Override
	public String getNombre() {
		return nombre;
	}

	@Override
	public float getPrecio() {
		return precio;
	}

	@Override
	public void agregar(Apuesta a) {}
	public void eliminar(Apuesta a) {}
	public void imprimirParley() {}

}
