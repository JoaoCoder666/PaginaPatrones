package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Controles;

public class AlambricoAntiguoAdapter implements Controles{
	private ControlAlambricoAntiguo control;
	
	public AlambricoAntiguoAdapter(ControlAlambricoAntiguo cAA)
	{
		setControl(cAA);
	}
	
	@Override
	public String confirmarConexion()
	{
		return this.control.conectar(1);
	}

	public ControlAlambricoAntiguo getControl() {
		return control;
	}

	public void setControl(ControlAlambricoAntiguo control) {
		this.control = control;
	}
	
	
}
