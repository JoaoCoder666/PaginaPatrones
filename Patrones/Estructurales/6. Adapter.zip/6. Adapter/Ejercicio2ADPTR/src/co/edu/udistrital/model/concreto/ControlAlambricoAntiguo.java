package co.edu.udistrital.model.concreto;

public class ControlAlambricoAntiguo {
	
	public String conectar(int c)
	{
		if(c == 1)
		{
			return "Conexion establecida mediante un adaptador especial";
		}
		else
		{
			return "IMPOSIBLE CONECTAR: El computador no cuenta con una entrada tan atigua";
		}
	}
}
