package co.edu.udistrital.model.abstracto;

public interface Controles {
	public String confirmarConexion();
}
