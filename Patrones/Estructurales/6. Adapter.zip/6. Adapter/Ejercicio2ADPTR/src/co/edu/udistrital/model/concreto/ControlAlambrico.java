package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Controles;

public class ControlAlambrico implements Controles{
	
	public String confirmarConexion()
	{
		return "Conexion establecida exitosamente!";
	}
}
