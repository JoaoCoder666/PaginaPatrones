package co.edu.udistrital.model.concreto;

public class ControlBlueTooth {
	
	public String conectar(int c)
	{
		if(c == 1)
		{
			return "Conexion establecida mediante dongle BlueTooth";
		}
		else
		{
			return "IMPOSIBLE CONECTAR: El computador no cuenta con BlueTooth";
		}
	}
}
