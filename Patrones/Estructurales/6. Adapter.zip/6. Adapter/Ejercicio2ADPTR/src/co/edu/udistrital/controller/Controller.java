package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Controles;
import co.edu.udistrital.model.concreto.AlambricoAntiguoAdapter;
import co.edu.udistrital.model.concreto.BlueToothAdapter;
import co.edu.udistrital.model.concreto.ControlAlambrico;
import co.edu.udistrital.model.concreto.ControlAlambricoAntiguo;
import co.edu.udistrital.model.concreto.ControlBlueTooth;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		this.vista = new Vista();
	}
	
	public void run()
	{
		Controles control;
		ControlAlambricoAntiguo controlAntiguo = new ControlAlambricoAntiguo();
		ControlBlueTooth controlBluetooth = new ControlBlueTooth();
		
		
		vista.mostrarInformacion("---Demostracion del patron Adapter---");
		
		vista.mostrarInformacion("Unico control compatible");
		
		control = new ControlAlambrico();
		vista.mostrarInformacion(control.confirmarConexion());
		
		vista.mostrarInformacion("Controles que no son compatibles: ");
		vista.mostrarInformacion(controlAntiguo.conectar(0) + "\n" + controlBluetooth.conectar(0));
		
		vista.mostrarInformacion("Controles adaptados: ");
		
		control = new AlambricoAntiguoAdapter(controlAntiguo);
		vista.mostrarInformacion(control.confirmarConexion());
		
		control = new BlueToothAdapter(controlBluetooth);
		vista.mostrarInformacion(control.confirmarConexion());
	}
}
