package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Controles;

public class BlueToothAdapter implements Controles{
	private ControlBlueTooth control;
	
	public BlueToothAdapter(ControlBlueTooth cBT)
	{
		setControl(cBT);
	}
	
	@Override
	public String confirmarConexion()
	{
		return this.control.conectar(1);
	}

	public ControlBlueTooth getControl() {
		return control;
	}

	public void setControl(ControlBlueTooth control) {
		this.control = control;
	}
	
	
}
