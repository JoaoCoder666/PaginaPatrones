package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Fotografias;

public class FisicasAdapter implements Fotografias{
	private Fisicas fisicas;
	
	public FisicasAdapter(Fisicas f)
	{
		setFisicas(f);
	}
	
	@Override
	public String exportar()
	{
		return this.fisicas.intentarExportar(1);
	}

	public Fisicas getFisicas() {
		return fisicas;
	}

	public void setFisicas(Fisicas fisicas) {
		this.fisicas = fisicas;
	}
	
	
}
