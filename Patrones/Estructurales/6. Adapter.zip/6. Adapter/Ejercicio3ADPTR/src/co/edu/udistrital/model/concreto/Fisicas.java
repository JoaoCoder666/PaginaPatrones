package co.edu.udistrital.model.concreto;

public class Fisicas {
	
	public String intentarExportar(int c)
	{
		if(c == 1)
		{
			return "Las fotografias fueron escaneadas y enviadas al dispositivo";
		}
		else
		{
			return "Imposible exportar las fotografias fisicas";
		}
	}
}
