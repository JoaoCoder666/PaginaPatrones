package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Fotografias;

public class DigitalesAdapter implements Fotografias{
	private Digitales digitales;
	
	public DigitalesAdapter(Digitales d)
	{
		setDigitales(d);
	}
	
	@Override
	public String exportar()
	{
		return this.digitales.intentarExportar(1);
	}

	public Digitales getDigitales() {
		return digitales;
	}

	public void setDigitales(Digitales digitales) {
		this.digitales = digitales;
	}
	
	
}
