package co.edu.udistrital.model.abstracto;

public interface Fotografias {
	public String exportar();
}
