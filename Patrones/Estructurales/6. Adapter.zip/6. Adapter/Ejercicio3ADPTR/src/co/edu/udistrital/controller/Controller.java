package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Fotografias;
import co.edu.udistrital.model.concreto.Digitales;
import co.edu.udistrital.model.concreto.DigitalesAdapter;
import co.edu.udistrital.model.concreto.Fisicas;
import co.edu.udistrital.model.concreto.FisicasAdapter;
import co.edu.udistrital.view.Vista;

public class Controller {
private Vista vista;
	
	public Controller()
	{
		this.vista = new Vista();
	}
	
	public void run()
	{
		Fotografias fotografias;
		Digitales digitales = new Digitales();
		Fisicas fisicas = new Fisicas();
		
		vista.mostrarInformacion("---Demostracion del patron Adapter---");
		
		vista.mostrarInformacion("Fotografias no compatibles para exportar: ");
		
		vista.mostrarInformacion(digitales.intentarExportar(0) + "\n" + fisicas.intentarExportar(0));
		
		vista.mostrarInformacion("Fotografias adaptadas para exportar: ");
		
		fotografias = new DigitalesAdapter(digitales);
		vista.mostrarInformacion(fotografias.exportar());
		
		fotografias = new FisicasAdapter(fisicas);
		vista.mostrarInformacion(fotografias.exportar());
	}
}
