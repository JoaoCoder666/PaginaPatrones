package co.edu.udistrital.model.concreto;

public class Digitales {
	
	public String intentarExportar(int c)
	{
		if(c == 1)
		{
			return "Se pudo exportar mediante la nube";
		}
		else
		{
			return "No se ha podido establecer una conexion con ningun dispositivo";
		}
	}
}
