package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Reproductores;

public class ReproductorMP3 implements Reproductores{
	private int duracion;
	
	public ReproductorMP3(int d)
	{
		setDuracion(d);
	}

	@Override
	public String reproducir()
	{
		return "Reproduciendo SOLO audio .MP3 de duracion: " + this.duracion;
	}
	
	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	
	
}
