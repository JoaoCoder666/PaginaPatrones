package co.edu.udistrital.model.concreto;

public class ReproductorMP4 {
	private int duracion;
	private int resolucion;
	
	public ReproductorMP4(int d, int r)
	{
		setDuracion(d);
		setResolucion(r);
	}
	
	public String reproducirContenido()
	{
		return "Reproduciendo video en: " + this.resolucion + " y audio de duracion: " + this.duracion;
	}

	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}

	public int getResolucion() {
		return resolucion;
	}

	public void setResolucion(int resolucion) {
		this.resolucion = resolucion;
	}
	
	
}
