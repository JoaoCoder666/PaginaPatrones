package co.edu.udistrital.model.abstracto;

public interface Reproductores {
	public String reproducir();
}
