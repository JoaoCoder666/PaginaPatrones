package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Reproductores;

public class ReproductorWAV implements Reproductores{
	private int duracion;
	
	public ReproductorWAV(int d)
	{
		setDuracion(d);
	}

	@Override
	public String reproducir()
	{
		return "Reproduciendo SOLO audio .WAV de duracion: " + this.duracion;
	}
	
	public int getDuracion() {
		return duracion;
	}

	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	
}
