package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Reproductores;

public class MP4Adapter implements Reproductores{
	private ReproductorMP4 reproductorAdaptado;
	
	public MP4Adapter(ReproductorMP4 rMP4)
	{
		setReproductorAdaptado(rMP4);
	}

	@Override
	public String reproducir()
	{
		return "--- Reproductor adaptado ---\n" + this.reproductorAdaptado.reproducirContenido();
	}
	
	public ReproductorMP4 getReproductorAdaptado() {
		return reproductorAdaptado;
	}

	public void setReproductorAdaptado(ReproductorMP4 reproductorAdaptado) {
		this.reproductorAdaptado = reproductorAdaptado;
	}
}
