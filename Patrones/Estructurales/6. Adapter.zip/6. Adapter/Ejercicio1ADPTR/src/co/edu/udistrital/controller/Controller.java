package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Reproductores;
import co.edu.udistrital.model.concreto.MP4Adapter;
import co.edu.udistrital.model.concreto.ReproductorMP3;
import co.edu.udistrital.model.concreto.ReproductorMP4;
import co.edu.udistrital.model.concreto.ReproductorWAV;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		this.vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Demostracion del patron Adapter---");
		
		Reproductores reproductor;
		ReproductorMP4 repMP4 = new ReproductorMP4(90, 1080);
		
		vista.mostrarInformacion("Reproductores inicialmente compatibles: ");
		
		reproductor = new ReproductorMP3(23);
		vista.mostrarInformacion(reproductor.reproducir());
		
		reproductor = new ReproductorWAV(50);
		vista.mostrarInformacion(reproductor.reproducir());
		
		vista.mostrarInformacion("Reproductor incompatible sin adaptar: ");
		vista.mostrarInformacion(repMP4.reproducirContenido());
		
		vista.mostrarInformacion("Reproductor incompatible adaptado: ");
		
		reproductor = new MP4Adapter(repMP4);
		vista.mostrarInformacion(reproductor.reproducir());
	}
}
