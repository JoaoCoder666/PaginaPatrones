package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Verificador;

public class VerificadorProxy implements Verificador{

	private VerificadorReal verificadorReal;
	private String contraProxy;
	
	public VerificadorProxy(String c)
	{
		this.contraProxy = c;
		verificadorReal = new VerificadorReal(c);
	}
	
	@Override
	public void verificar() 
	{	
		System.out.println("------Analizando la contraseña------");
		try
		{
			System.out.println("**consultando**");
			Thread.sleep(2000);
			System.out.println("**Finalizando**");
			Thread.sleep(2000);
		}
		catch(InterruptedException e)
		{
			System.out.println("error al acceder");
		}
		verificadorReal.verificar();
	}

	public VerificadorReal getVerificadorReal() {
		return verificadorReal;
	}

	public void setVerificadorReal(VerificadorReal verificadorReal) {
		this.verificadorReal = verificadorReal;
	}

	public String getContraProxy() {
		return contraProxy;
	}

	public void setContraProxy(String contraProxy) {
		this.contraProxy = contraProxy;
	}
	
	

}
