package co.edu.udistrital.model.abstracto;

public interface Verificador {
	void verificar();
}
