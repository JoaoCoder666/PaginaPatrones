package co.edu.udistrital.controller;

import co.edu.udistrital.model.VerificadorProxy;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Comprobador de contaseñas");
		String contra = vista.leerCadenaDeTexto("Ingrese la contaseña deseada");
		VerificadorProxy vP = new VerificadorProxy(contra);
		vP.verificar();
	}
}
