package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Verificador;

public class VerificadorReal implements Verificador{

	private String contra;
	
	public VerificadorReal(String c)
	{
		this.contra = c;
	}
	
	@Override
	public void verificar() {
		if(this.contra.toLowerCase().charAt(0) == 'a')
		{
			System.out.println("La contraseña no es segura");
		}
		else
		{
			System.out.println("La contraseña es muy segura");
		}
	}

	public String getContra() {
		return contra;
	}

	public void setContra(String contra) {
		this.contra = contra;
	}
	
	
}
