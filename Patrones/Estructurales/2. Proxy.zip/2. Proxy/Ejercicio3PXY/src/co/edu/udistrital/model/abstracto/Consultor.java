package co.edu.udistrital.model.abstracto;

public interface Consultor {
	void consultar();
}
