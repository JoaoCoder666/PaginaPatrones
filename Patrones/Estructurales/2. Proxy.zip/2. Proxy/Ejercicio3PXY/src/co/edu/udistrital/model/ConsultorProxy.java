package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Consultor;

public class ConsultorProxy implements Consultor{

	private ConsultorReal consultorReal;
	private String rolProxy;
	
	public ConsultorProxy(String rP)
	{
		this.setRolProxy(rP);
		consultorReal = new ConsultorReal(rP);
	}
	
	@Override
	public void consultar() {
		System.out.println("------Accediendo a la base de datos------");
		try
		{
			System.out.println("**consultando**");
			Thread.sleep(2000);
			System.out.println("**Finalizando**");
			Thread.sleep(2000);
		}
		catch(InterruptedException e)
		{
			System.out.println("error al acceder");
		}
		consultorReal.consultar();
	}

	public String getRolProxy() {
		return rolProxy;
	}

	public void setRolProxy(String rolProxy) {
		this.rolProxy = rolProxy;
	}
}
