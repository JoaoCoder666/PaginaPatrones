package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Consultor;

public class ConsultorReal implements Consultor{

	private String rol;
	
	public ConsultorReal(String r)
	{
		this.setRol(r);
	}
	
	@Override
	public void consultar() {
		if(this.rol.toLowerCase().equals("ejecutivo") || this.rol.toLowerCase().equals("empleado") || this.rol.toLowerCase().equals("CEO"))
		{
			System.out.println("Rol valido");
		}
		else
		{
			System.out.println("Rol invalido");
		}
	}

	public String getRol() {
		return rol;
	}

	public void setRol(String rol) {
		this.rol = rol;
	}
}
