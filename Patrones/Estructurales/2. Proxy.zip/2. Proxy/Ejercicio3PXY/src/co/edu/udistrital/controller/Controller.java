package co.edu.udistrital.controller;

import co.edu.udistrital.model.ConsultorProxy;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Empresa confidencial, slo tres roles validos");
		
		String rol = vista.leerCadenaDeTexto("Ingrese su rol en la empresa: ");
		ConsultorProxy vP = new ConsultorProxy(rol);
		vP.consultar();
	}
}