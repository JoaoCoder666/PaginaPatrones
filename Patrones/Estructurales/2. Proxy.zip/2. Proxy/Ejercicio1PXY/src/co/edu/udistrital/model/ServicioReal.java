package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Servicio;

public class ServicioReal implements Servicio {

	private String usuario;
	
	public ServicioReal(String usuario)
	{
		this.setUsuario(usuario);
	}
	
	@Override
	public void verificar() 
	{
		if(this.usuario.charAt(1) == 'e')
		{
			System.out.println("El usuario: " + this.usuario + " NO tiene acceso");
		}
		else
		{
			System.out.println("El usuario: " + this.usuario + " tiene acceso");
		}
	}

	public String getUsuario() {
		return usuario;
	}

	public void setUsuario(String usuario) {
		this.usuario = usuario;
	}

}
