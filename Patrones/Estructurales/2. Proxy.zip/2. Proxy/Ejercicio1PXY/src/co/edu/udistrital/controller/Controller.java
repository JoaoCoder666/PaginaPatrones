package co.edu.udistrital.controller;

import co.edu.udistrital.model.ServicioProxy;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		String nombre = "";
		ServicioProxy servicio;
		
		vista.mostrarInformacion("Bienvenido");
		nombre = vista.leerCadenaDeTexto("Ingrese el nombre del usuario: ");
		servicio = new ServicioProxy(nombre);
		servicio.verificar();
	}
}
