package co.edu.udistrital.model.abstracto;

public interface Servicio {
	void verificar();
}
