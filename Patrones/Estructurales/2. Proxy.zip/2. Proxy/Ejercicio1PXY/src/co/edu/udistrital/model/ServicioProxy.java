package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Servicio;

public class ServicioProxy implements Servicio{

	private ServicioReal servicioReal;
	private String nombre = "";
	
	public ServicioProxy(String nombre)
	{
		servicioReal = new ServicioReal(nombre);
		this.setNombre(nombre);
	}
	
	@Override
	public void verificar() 
	{
		System.out.println("------Accediendo a la base de datos------");
		try
		{
			System.out.println("**consultando**");
			Thread.sleep(2000);
			System.out.println("**Finalizando**");
			Thread.sleep(2000);
		}
		catch(InterruptedException e)
		{
			System.out.println("error al acceder");
		}
		servicioReal.verificar();
	}

	public ServicioReal getServicioReal() {
		return servicioReal;
	}

	public void setServicioReal(ServicioReal servicioReal) {
		this.servicioReal = servicioReal;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
