package co.edu.udistrital.model;

import java.util.HashMap;

public class GuitarraFactory {
	private static HashMap<String, GuitarraFlyWeight> map = new HashMap<>();
	
	public static GuitarraFlyWeight getGuitarraFW(String tipoMic, String tipoPuente)
	{
		if(map.get(tipoMic.toLowerCase()) == null)
		{
			map.put(tipoMic, new GuitarraFlyWeight(tipoMic, tipoPuente));
			System.out.print("\n|||Nuevo tipo de microfono creado|||\n");
		}
		
		return map.get(tipoMic);
	}
	
	public static GuitarraFlyWeight imprimirTipos(String tipoMic)
	{
		return map.get(tipoMic);
	}
}
