package co.edu.udistrital.model;

public class Guitarra {
	private int cantCuerdas;
	private int cantMic;
	private int cantTrast;
	
	public Guitarra(int cC, int cM, int cT)
	{
		setCantCuerdas(cC);
		setCantMic(cM);
		setCantTrast(cT);
	}

	public int getCantCuerdas() {
		return cantCuerdas;
	}

	public void setCantCuerdas(int cantCuerdas) {
		this.cantCuerdas = cantCuerdas;
	}

	public int getCantMic() {
		return cantMic;
	}

	public void setCantMic(int cantMic) {
		this.cantMic = cantMic;
	}

	public int getCantTrast() {
		return cantTrast;
	}

	public void setCantTrast(int cantTrast) {
		this.cantTrast = cantTrast;
	}
	
	@Override
	public String toString()
	{
		return "-------\nCantidad de cuerdas: " + this.cantCuerdas + ", cantidad de microfonos: " + this.cantMic + ", cantidad de trastes: " + this.cantTrast;
	}
}
