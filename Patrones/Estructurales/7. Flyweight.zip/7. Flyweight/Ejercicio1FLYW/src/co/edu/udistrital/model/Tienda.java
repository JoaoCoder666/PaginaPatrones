package co.edu.udistrital.model;

import java.util.ArrayList;

public class Tienda {
	private ArrayList<Guitarra> guitarras = new ArrayList<>();

	public Tienda() {}
	
	public void agregarGuitarra(String tipoMic, String tipoPuente, int cantCuerdas, int cantMic, int cantTrast)
	{
		@SuppressWarnings("unused")
		GuitarraFlyWeight newGuit = GuitarraFactory.getGuitarraFW(tipoMic, tipoPuente);
		guitarras.add(new Guitarra(cantCuerdas, cantMic, cantTrast));
	}
	
	public String imprimirGuitarras(String tipoMic, int index)
	{
		String salida = "";
		GuitarraFlyWeight guit = GuitarraFactory.imprimirTipos(tipoMic);
		
		salida += guitarras.get(index).toString();
		salida += guit.toString();
		
		return salida;
	}
		
	public ArrayList<Guitarra> getGuitarras() {
		return guitarras;
	}

	public void setGuitarras(ArrayList<Guitarra> guitarras) {
		this.guitarras = guitarras;
	}
}	
