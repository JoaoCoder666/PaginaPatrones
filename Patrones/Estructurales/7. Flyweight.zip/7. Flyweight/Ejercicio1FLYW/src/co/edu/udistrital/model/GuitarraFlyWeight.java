package co.edu.udistrital.model;

public class GuitarraFlyWeight {
	private String tipoMic;
	private String tipoPunte;
	
	public GuitarraFlyWeight(String tM, String tP)
	{
		this.tipoMic = tM;
		this.tipoPunte = tP;
	}
	
	public String getTipoMic() {
		return tipoMic;
	}

	public String getTipoPunte() {
		return tipoPunte;
	}
	
	@Override
	public String toString()
	{
		return "\nTipo de microfonos: " + this.tipoMic + ", tipo de puente: " + this.tipoPunte + "\n------\n";
	}
}
