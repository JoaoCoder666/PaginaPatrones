package co.edu.udistrital.controller;

import co.edu.udistrital.model.Tienda;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		this.vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Creador de guitarras con el patron flyweight");
		
		Tienda tienda = new Tienda();
		
		String tipoMic = "";
		String tipoPuente = "";
		int cantCuerdas = 0;
		int cantMic = 0;
		int cantTrast = 0;
		
		String salida = "";
		
		while(true)
		{
			tienda.getGuitarras().clear();
			int cantGuit = Integer.parseInt(vista.leerCadenaDeTexto("Cuantas guitarra quiere crear?"));
			
			for(int i = 0; i < cantGuit; i++)
			{
				vista.mostrarInformacion((i+1) + " Guitarra\n");
				
				tipoMic = vista.leerCadenaDeTexto("Tipo de microfono: ");
				tipoPuente = vista.leerCadenaDeTexto("Tipo de puente: ");
				
				cantCuerdas = Integer.parseInt(vista.leerCadenaDeTexto("Cantidad de cuerdas: "));
				cantMic = Integer.parseInt(vista.leerCadenaDeTexto("Cantidad de microfonos: "));
				cantTrast = Integer.parseInt(vista.leerCadenaDeTexto("Cantidad de trastes: "));
				
				tienda.agregarGuitarra(tipoMic, tipoPuente, cantCuerdas, cantMic, cantTrast);
				salida += tienda.imprimirGuitarras(tipoMic,i);
			}
			
			vista.mostrarInformacion(salida);
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2 no"));
			
			if(cont == 1)
			{
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
