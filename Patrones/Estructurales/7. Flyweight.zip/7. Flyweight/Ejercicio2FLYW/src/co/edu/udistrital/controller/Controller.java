package co.edu.udistrital.controller;

import co.edu.udistrital.model.Concesionario;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		this.vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Creacion de carros usando el patron flyweight");
		
		Concesionario concesionario = new Concesionario();
		
		String tipoMotor = "";
		String tipoCombustible = "";
		String cantLlantas = "";
		
		String color = "";
		String tipoLlanta = "";
		String tipoRin = "";
		
		String salida = "";
		
		while(true)
		{
			concesionario.getLista().clear();
			int cant = Integer.parseInt(vista.leerCadenaDeTexto("Cuantos carros desea crear?"));
			
			for(int i = 0; i < cant; i++)
			{
				vista.mostrarInformacion((i+1) + " Carro\n");
				
				tipoMotor = vista.leerCadenaDeTexto("Tipo del motor: ");
				tipoCombustible = vista.leerCadenaDeTexto("Tipo de combustible: ");
				cantLlantas = vista.leerCadenaDeTexto("Cantidad de llantas: ");
				color = vista.leerCadenaDeTexto("Color del carro: ");
				tipoLlanta = vista.leerCadenaDeTexto("Tipo de llanta: ");
				tipoRin = vista.leerCadenaDeTexto("Tipo de rin");
				
				concesionario.agregarCarro(tipoMotor, tipoCombustible, cantLlantas, color, tipoLlanta, tipoRin);
				salida += concesionario.imprimirCarros(tipoMotor, i);
			}
			
			vista.mostrarInformacion(salida);
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2 no"));
			
			if(cont == 1)
			{
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
