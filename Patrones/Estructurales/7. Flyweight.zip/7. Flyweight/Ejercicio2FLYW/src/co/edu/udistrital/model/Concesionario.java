package co.edu.udistrital.model;

import java.util.ArrayList;

public class Concesionario {
	private ArrayList<Carro> lista = new ArrayList<>();

	public Concesionario() {} 
	
	public void agregarCarro(String tipoMotor, String tipoCombustible, String cantLlantas, String color, String tipoLlantas, String tipoRin)
	{
		@SuppressWarnings("unused")
		CarroFlyWeight newCarro = CarroFactory.getCarroFW(tipoMotor, tipoCombustible, cantLlantas);
		
		lista.add(new Carro(color, tipoLlantas, tipoRin));
	}
	
	public String imprimirCarros(String tipoMotor, int index)
	{
		String salida = "";
		CarroFlyWeight cFW = CarroFactory.imprimirCarrosFW(tipoMotor);
		
		salida += lista.get(index).toString();
		salida += cFW.toString();
		
		return salida;
	}
	
	
	public ArrayList<Carro> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Carro> lista) {
		this.lista = lista;
	}
}

