package co.edu.udistrital.model;

public class CarroFlyWeight {
	private String tipoMotor;
	private String tipoCombustible;
	private String cantLlantas;
	
	public CarroFlyWeight(String tM, String tC, String cL)	
	{
		this.tipoMotor = tM;
		this.tipoCombustible = tC;
		this.cantLlantas = cL;
	}

	public String getTipoMotor() {
		return tipoMotor;
	}

	public String getTipoCombustible() {
		return tipoCombustible;
	}

	public String getCantLlantas() {
		return cantLlantas;
	}
	
	@Override
	public String toString()
	{
		return "\nTipo de motor: " + this.tipoMotor + ", tipo de combustible: " + this.tipoCombustible + ", cantidad de llantas: " + this.cantLlantas + "\n------\n";
	}
}	
