package co.edu.udistrital.model;

public class Carro {
	private String color;
	private String tipoLlantas;
	private String tipoRin;
	
	public Carro(String c, String tL, String tR)
	{
		setColor(c);
		setTipoLlantas(tL);
		setTipoRin(tR);
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getTipoLlantas() {
		return tipoLlantas;
	}

	public void setTipoLlantas(String tipoLlantas) {
		this.tipoLlantas = tipoLlantas;
	}

	public String getTipoRin() {
		return tipoRin;
	}

	public void setTipoRin(String tipoRin) {
		this.tipoRin = tipoRin;
	}
	
	@Override
	public String toString()
	{
		return "\n------\nColor: " + this.color + ", tipo de llantas: " + this.tipoLlantas + ", tipo de rin: " + this.tipoRin;
	}
}
