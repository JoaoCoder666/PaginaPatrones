package co.edu.udistrital.model;

import java.util.HashMap;

public class CarroFactory {
	private static HashMap<String, CarroFlyWeight> map = new HashMap<>();
	
	public static CarroFlyWeight getCarroFW(String tipoMotor, String tipoCobuistible, String cantLlantas)
	{
		if(map.get(tipoMotor.toLowerCase()) == null)
		{
			map.put(tipoMotor,  new CarroFlyWeight(tipoMotor, tipoCobuistible, cantLlantas));
			System.out.println("\n|||Nuevo tipo de motor creado|||\n");
		}
		
		return map.get(tipoMotor);
	}
	
	public static CarroFlyWeight imprimirCarrosFW(String tipoMotor)
	{
		return map.get(tipoMotor);
	}
}
