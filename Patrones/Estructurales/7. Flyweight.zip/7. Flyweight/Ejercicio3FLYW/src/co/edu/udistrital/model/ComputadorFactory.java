package co.edu.udistrital.model;

import java.util.HashMap;

public class ComputadorFactory {
	private static HashMap<String, ComputadorFlyWeight> map = new HashMap<>();
	
	public static ComputadorFlyWeight getComputadorFW(String procesador, String motherboard, String discoDuro, String ram)
	{
		if(map.get(procesador.toLowerCase()) == null)
		{
			map.put(procesador, new ComputadorFlyWeight(procesador, motherboard, discoDuro, ram));
			System.out.println("|||Nuevo tipo de procesador creado|||");
		}
		
		return map.get(procesador);
	}
	
	public static ComputadorFlyWeight imprimirCmputadorFW(String procesador)
	{
		return map.get(procesador);
	}
}

