package co.edu.udistrital.model;

import java.util.ArrayList;

public class Tienda {
	private ArrayList<Computador> lista = new ArrayList<>();
	
	public Tienda() {}
	
	public void agregarComputador(String procesador, String motherboard, String discoDuro, String ram, String tarjetaGrafica, String chasis, String refrigeracion)
	{
		
		@SuppressWarnings("unused")
		ComputadorFlyWeight compFW = ComputadorFactory.getComputadorFW(procesador, motherboard, discoDuro, ram);	
		lista.add(new Computador(tarjetaGrafica, chasis, refrigeracion));
	}
	
	public String imprimirComputadores(String procesador, int index)
	{
		String salida = "";
		
		salida += lista.get(index).toString();
		salida += ComputadorFactory.imprimirCmputadorFW(procesador).toString();
		
		return salida;
	}

	public ArrayList<Computador> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Computador> lista) {
		this.lista = lista;
	}
	
}
