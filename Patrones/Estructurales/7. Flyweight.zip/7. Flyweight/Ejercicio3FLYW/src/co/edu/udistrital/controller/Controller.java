package co.edu.udistrital.controller;

import co.edu.udistrital.model.Tienda;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		this.vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Creacion de Computadores usando el patron flyweight");
		
		Tienda tienda = new Tienda();
		
		String procesador = "";
		String motherboard = "";
		String discoDuro = "";
		String ram = "";
		
		String tarjetaGrafica = "";
		String chasis = "";
		String refrigeracion = "";
		
		String salida = "";
		
		while(true)
		{
			tienda.getLista().clear();
			
			int cant = Integer.parseInt(vista.leerCadenaDeTexto("Cuantos computadores desea crear? "));
			
			for(int i = 0; i < cant; i++)
			{
				vista.mostrarInformacion((i+1) + " Computador");
				
				procesador = vista.leerCadenaDeTexto("Tipo de procesador: ");
				motherboard = vista.leerCadenaDeTexto("Motherboard: ");
				discoDuro = vista.leerCadenaDeTexto("Disco duro: ");
				ram = vista.leerCadenaDeTexto("Cantidad de ram: ");
				tarjetaGrafica = vista.leerCadenaDeTexto("Tarjeta Grafica: ");
				chasis = vista.leerCadenaDeTexto("Chasis: ");
				refrigeracion = vista.leerCadenaDeTexto("Refrigeracion: ");
				
				tienda.agregarComputador(procesador, motherboard, discoDuro, ram, tarjetaGrafica, chasis, refrigeracion);
				salida += tienda.imprimirComputadores(procesador, i);
			}
			
			vista.mostrarInformacion(salida);
			
			int cont = Integer.parseInt(vista.leerCadenaDeTexto("Desea continuar en el programa?"
					+ "\n1. si"
					+ "\n2 no"));
			
			if(cont == 1)
			{
				continue;
			}
			else
			{
				vista.mostrarInformacion("Gracias por usar el programa!");
				System.exit(0);
			}
		}
	}
}
