package co.edu.udistrital.model;

public class ComputadorFlyWeight {
	private String procesador;
	private String motherboard;
	private String discoDuro;
	private String ram;
	
	public ComputadorFlyWeight(String p, String m, String dD, String r)
	{
		this.procesador = p;
		this.motherboard = m;
		this.discoDuro = dD;
		this.ram = r;
	}

	public String getProcesador() {
		return procesador;
	}

	public String getMotherboard() {
		return motherboard;
	}

	public String getDiscoDuro() {
		return discoDuro;
	}

	public String getRam() {
		return ram;
	}
	
	@Override
	public String toString()
	{
		return "\nProcesador: " + this.procesador + ", motherboard: " + this.motherboard + ", disco duro: " + this.discoDuro + ", ram: " + this.ram + "\n------\n";
	}
}

