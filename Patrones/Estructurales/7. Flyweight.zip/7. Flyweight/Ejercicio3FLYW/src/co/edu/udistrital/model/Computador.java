package co.edu.udistrital.model;

public class Computador {
	private String tarjetaGrafica;
	private String  chasis;
	private String refrigeracion;
	
	public Computador(String tG, String c, String r)
	{
		setTarjetaGrafica(tG);
		setChasis(c);
		setRefrigeracion(r);
	}

	public String getTarjetaGrafica() {
		return tarjetaGrafica;
	}

	public void setTarjetaGrafica(String tarjetaGrafica) {
		this.tarjetaGrafica = tarjetaGrafica;
	}

	public String getChasis() {
		return chasis;
	}

	public void setChasis(String chasis) {
		this.chasis = chasis;
	}

	public String getRefrigeracion() {
		return refrigeracion;
	}

	public void setRefrigeracion(String refrigeracion) {
		this.refrigeracion = refrigeracion;
	}
	
	@Override
	public String toString()
	{
		return "\n------\nTarjeta Grafica: " + this.tarjetaGrafica + ", Chasis" + this.chasis + ", refrigeracion: " + this.refrigeracion;
	}
}
