package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.DecoratorBanda;

public class Guitarra extends DecoratorBanda{
	private Banda banda;
	
	public Guitarra(Banda b)
	{
		this.banda = b; 
	}
	
	@Override
	public String getDescripcion()
	{
		return this.banda.getDescripcion() + "\n\tGuitarra";
	}
}
