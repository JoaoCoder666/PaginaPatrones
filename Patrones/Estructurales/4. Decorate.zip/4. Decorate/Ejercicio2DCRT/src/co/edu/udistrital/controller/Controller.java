package co.edu.udistrital.controller;

import co.edu.udistrital.model.Bajo;
import co.edu.udistrital.model.Banda;
import co.edu.udistrital.model.Bateria;
import co.edu.udistrital.model.Guitarra;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Construir una Banda---");
		
		Banda banda = new Banda();
		int decision = 0;
		
		while(true)
		{
			decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea: "
					+ "\n1. Agregar Guitarra"
					+ "\n2. Agregar Bateria"
					+ "\n3. Agregar Bajo"
					+ "\n4. Terminar composicion"));
			
			switch(decision)
			{
			case 1:
				banda = new Guitarra(banda);
				vista.mostrarInformacion("\n---\nAgregado Exitosamente\n---\n");
			case 2:
				banda = new Bateria(banda);
				vista.mostrarInformacion("\n---\nAgregado Exitosamente\n---\n");
			case 3:
				banda = new Bajo(banda);
				vista.mostrarInformacion("\n---\nAgregado Exitosamente\n---\n");
			case 4:
				vista.mostrarInformacion("Composicion: ");
				vista.mostrarInformacion("-------------------");
				vista.mostrarInformacion(banda.getDescripcion());
				vista.mostrarInformacion("-------------------");
				
				decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea:"
						+ "\n1. Continuar en el programa"
						+ "\n2. Salir"));
				
				if(decision == 1)
				{
					banda = new Banda();
					decision = 0;
				}
				else
				{
					vista.mostrarInformacion("Gracias por usar el programa!");
					System.exit(0);
				}
			}
		}
	}	
}
