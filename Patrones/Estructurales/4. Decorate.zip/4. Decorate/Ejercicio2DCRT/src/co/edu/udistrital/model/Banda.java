package co.edu.udistrital.model;

public class Banda {
	public String getDescripcion()
	{
		return "Banda con:"
				+ "\n\tCantante";
	}
}
