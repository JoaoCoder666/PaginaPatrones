package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.DecoratorBanda;

public class Bajo extends DecoratorBanda{
	private Banda banda;
	
	public Bajo(Banda b)
	{
		this.banda = b; 
	}
	
	@Override
	public String getDescripcion()
	{
		return this.banda.getDescripcion() + "\n\tBajo";
	}
}
