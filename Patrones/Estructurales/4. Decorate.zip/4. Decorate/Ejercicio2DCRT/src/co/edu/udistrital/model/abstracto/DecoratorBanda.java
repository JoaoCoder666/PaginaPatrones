package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Banda;

public abstract class DecoratorBanda extends Banda{
	@Override
	public abstract String getDescripcion();
}
