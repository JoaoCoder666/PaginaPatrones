package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.DecoracionCafe;

public class Leche extends DecoracionCafe{
	private Cafe cafe;
	
	public Leche(Cafe c)
	{
		this.cafe = c;
	}

	@Override
	public String getDescripcion() 
	{
		return this.cafe.getDescripcion() + "\nCon Leche";
	}

}
