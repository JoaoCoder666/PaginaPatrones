package co.edu.udistrital.model;

public class Cafe {
	public String getDescripcion()
	{
		return "Cafe sencillo";
	}
}
