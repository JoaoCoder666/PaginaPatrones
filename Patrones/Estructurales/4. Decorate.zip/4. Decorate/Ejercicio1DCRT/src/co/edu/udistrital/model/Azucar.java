package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.DecoracionCafe;

public class Azucar extends DecoracionCafe{
	private Cafe cafe;
	
	public Azucar(Cafe c)
	{
		this.cafe = c; 
	}

	@Override
	public String getDescripcion() 
	{
		return this.cafe.getDescripcion() + "\nCon azucar";
	}	
}
