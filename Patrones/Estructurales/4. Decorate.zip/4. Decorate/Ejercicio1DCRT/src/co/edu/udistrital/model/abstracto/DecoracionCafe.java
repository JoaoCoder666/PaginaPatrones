package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Cafe;

public abstract class DecoracionCafe extends Cafe{

    @Override
    public abstract String getDescripcion();

}
