package co.edu.udistrital.controller;

import co.edu.udistrital.model.Azucar;
import co.edu.udistrital.model.Cafe;
import co.edu.udistrital.model.Leche;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Hacer pedido de un cafe---");
		
		Cafe cafe  = new Cafe();
		int decision = 0;
		
		while(true)
		{
			decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea: "
					+ "\n1. Agregar Azucar"
					+ "\n2. Agregar Leche"
					+ "\n3. Terminar pedido"));
			
			switch(decision)
			{
			case 1:
				cafe = new Azucar(cafe);
				vista.mostrarInformacion("Adicion completada");
				continue;
			case 2:
				cafe = new Leche(cafe);
				vista.mostrarInformacion("Adicion completada");
				continue;
			case 3:
				vista.mostrarInformacion("Pedido: ");
				vista.mostrarInformacion("-------------------");
				vista.mostrarInformacion(cafe.getDescripcion());
				vista.mostrarInformacion("-------------------");
				
				decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea:"
						+ "\n1. Continuar en el programa"
						+ "\n2. Salir"));
				
				if(decision == 1)
				{
					cafe = new Cafe();
					decision = 0;
				}
				else
				{
					vista.mostrarInformacion("Gracias por usar el programa!");
					System.exit(0);
				}
			}
			
		}
	}
}
