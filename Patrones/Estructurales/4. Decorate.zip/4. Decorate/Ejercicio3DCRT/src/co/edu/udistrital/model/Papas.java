package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.DecoratorHamburguesa;

public class Papas extends DecoratorHamburguesa{
	private Hamburguesa hamburguesa;
	
	public Papas(Hamburguesa h)
	{
		this.hamburguesa = h;
	}
	
	@Override
	public String getDescripcion()
	{
		return this.hamburguesa.getDescripcion() + "\nCon Papas";
	}
}
