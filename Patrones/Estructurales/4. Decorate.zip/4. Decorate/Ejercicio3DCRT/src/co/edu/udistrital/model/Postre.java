package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.DecoratorHamburguesa;

public class Postre extends DecoratorHamburguesa{
	private Hamburguesa hamburguesa;
	
	public Postre(Hamburguesa h)
	{
		this.hamburguesa = h;
	}
	
	@Override
	public String getDescripcion()
	{
		return this.hamburguesa.getDescripcion() + "\nCon Postre";
	}
}
