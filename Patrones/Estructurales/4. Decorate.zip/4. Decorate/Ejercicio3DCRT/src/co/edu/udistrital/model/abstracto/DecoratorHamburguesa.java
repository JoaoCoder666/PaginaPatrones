package co.edu.udistrital.model.abstracto;

import co.edu.udistrital.model.Hamburguesa;

public abstract class DecoratorHamburguesa extends Hamburguesa{
	public abstract String getDescripcion();
}
