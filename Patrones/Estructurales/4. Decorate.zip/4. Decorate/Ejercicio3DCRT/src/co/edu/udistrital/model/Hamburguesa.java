package co.edu.udistrital.model;

public class Hamburguesa {
	public String getDescripcion()
	{
		return "Hamburguesa con: ";
	}
}
