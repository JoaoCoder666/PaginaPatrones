package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.DecoratorHamburguesa;

public class Bebida extends DecoratorHamburguesa{
	private Hamburguesa hamburguesa;
	
	public Bebida(Hamburguesa h)
	{
		this.hamburguesa = h;
	}
	
	@Override
	public String getDescripcion()
	{
		return this.hamburguesa.getDescripcion() + "\nCon Bebida";
	}
}
