package co.edu.udistrital.controller;

import co.edu.udistrital.model.Bebida;
import co.edu.udistrital.model.Hamburguesa;
import co.edu.udistrital.model.Papas;
import co.edu.udistrital.model.Postre;
import co.edu.udistrital.view.Vista;

public class Controller {
private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Construir una Banda---");
		
		Hamburguesa hamburguesa = new Hamburguesa();
		int decision = 0;
		
		while(true)
		{
			decision = Integer.parseInt(vista.leerCadenaDeTexto("Desea: "
					+ "\n1. Agregar Papas"
					+ "\n2. Agregar Bebida"
					+ "\n3. Agregar Postre"
					+ "\n4. Terminar pedido"));
			
			switch(decision)
			{
			case 1:
				hamburguesa = new Papas(hamburguesa);
				vista.mostrarInformacion("\n---\nAgregado Exitosamente\n---\n");
			case 2:
				hamburguesa = new Bebida(hamburguesa);
				vista.mostrarInformacion("\n---\nAgregado Exitosamente\n---\n");
			case 3:
				hamburguesa = new Postre(hamburguesa);
				vista.mostrarInformacion("\n---\nAgregado Exitosamente\n---\n");
			case 4:
				
			}
		}
	}
}
