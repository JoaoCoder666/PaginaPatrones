package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Color;

public class Rojo implements Color{

	@Override
	public String colorear() {
		return "de color: Rojo";
	}

}
