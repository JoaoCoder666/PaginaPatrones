package co.edu.udistrital.model.abstracto;

public abstract class Forma {
	private Color color;
	
	public Forma(Color col)
	{
		this.setColor(col);
	}
	
	public abstract String describir();

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
}
