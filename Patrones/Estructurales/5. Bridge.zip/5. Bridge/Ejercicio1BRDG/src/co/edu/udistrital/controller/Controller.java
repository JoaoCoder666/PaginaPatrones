package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Color;
import co.edu.udistrital.model.abstracto.Forma;
import co.edu.udistrital.model.concreto.Circulo;
import co.edu.udistrital.model.concreto.Cuadrado;
import co.edu.udistrital.model.concreto.Naranja;
import co.edu.udistrital.model.concreto.Rojo;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Demostracion de la separacion de abstraccion e implementacion---");
		
		Forma forma1;
		Forma forma2;
		Color color;
		
		vista.mostrarInformacion("Con el color Rojo: ");
		color = new Rojo();
		
		
		forma1 = new Circulo(color);
		forma2 = new Cuadrado(color);
		vista.mostrarInformacion(forma1.describir());
		vista.mostrarInformacion(forma2.describir());
		
		vista.mostrarInformacion("Con el color Naranja: ");
		color = new Naranja();
		
		forma1.setColor(color);
		forma2.setColor(color);
		vista.mostrarInformacion(forma1.describir());
		vista.mostrarInformacion(forma2.describir());		
	}
}
