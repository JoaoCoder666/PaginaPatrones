package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Color;
import co.edu.udistrital.model.abstracto.Forma;

public class Circulo  extends Forma{

	public Circulo(Color col) 
	{
		super(col);
	}

	@Override
	public String describir() 
	{
		return "Circulo "+ this.getColor().colorear();
	}	

}
