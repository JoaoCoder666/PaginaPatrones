package co.edu.udistrital.model.abstracto;

public abstract class Mando {
	private Consola consola;
	
	public Mando(Consola con)
	{
		this.setConsola(con);
	}
	
	public abstract String describir();

	public Consola getConsola() {
		return consola;
	}

	public void setConsola(Consola consola) {
		this.consola = consola;
	}
}
