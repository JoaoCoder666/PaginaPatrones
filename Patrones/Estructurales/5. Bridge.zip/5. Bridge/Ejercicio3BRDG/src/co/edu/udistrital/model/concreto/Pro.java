package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Consola;
import co.edu.udistrital.model.abstracto.Mando;

public class Pro extends Mando{

	public Pro(Consola con) 
	{
		super(con);
	}

	@Override
	public String describir() 
	{
		return "Control Pro de: " + this.getConsola().describir();
	}

}
