package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Consola;
import co.edu.udistrital.model.abstracto.Mando;
import co.edu.udistrital.model.concreto.Clasico;
import co.edu.udistrital.model.concreto.Nintendo;
import co.edu.udistrital.model.concreto.Playstation;
import co.edu.udistrital.model.concreto.Pro;
import co.edu.udistrital.model.concreto.Xbox;
import co.edu.udistrital.view.Vista;

public class Controller {
private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Demostracion de la separacion de abstraccion e implementacion---");
		
		Mando mando1;
		Mando mando2;
		Consola consola;
		
		vista.mostrarInformacion("Controles para consola Xbox");
		consola = new Xbox();
		
		mando1 = new Clasico(consola);
		mando2 = new Pro(consola);
		
		vista.mostrarInformacion(mando1.describir());
		vista.mostrarInformacion(mando2.describir());
		
		vista.mostrarInformacion("Controles para consola PlayStation");
		consola = new Playstation();
		
		mando1.setConsola(consola);
		mando2.setConsola(consola);
		
		vista.mostrarInformacion(mando1.describir());
		vista.mostrarInformacion(mando2.describir());
		
		vista.mostrarInformacion("Controles para consola Nintendo");
		consola = new Nintendo();
		
		vista.mostrarInformacion(mando1.describir());
		vista.mostrarInformacion(mando2.describir());
	}
}
