package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Consola;
import co.edu.udistrital.model.abstracto.Mando;

public class Clasico extends Mando{

	public Clasico(Consola con) 
	{
		super(con);
	}

	@Override
	public String describir() 
	{
		return "Control clasico de: " + this.getConsola().describir();
	}

}
