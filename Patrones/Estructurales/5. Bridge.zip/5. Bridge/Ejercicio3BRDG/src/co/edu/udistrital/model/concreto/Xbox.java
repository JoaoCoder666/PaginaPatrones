package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Consola;

public class Xbox implements Consola{

	@Override
	public String describir() 
	{
		return "Xbox";
	}

}
