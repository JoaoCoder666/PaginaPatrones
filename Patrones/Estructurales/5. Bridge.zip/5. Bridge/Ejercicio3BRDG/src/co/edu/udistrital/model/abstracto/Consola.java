package co.edu.udistrital.model.abstracto;

public interface Consola {
	public String describir(); 
}
