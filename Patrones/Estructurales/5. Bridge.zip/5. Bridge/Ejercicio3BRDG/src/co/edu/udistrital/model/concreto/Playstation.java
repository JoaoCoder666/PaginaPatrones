package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Consola;

public class Playstation implements Consola{

	@Override
	public String describir() 
	{
		return "PlayStation";
	}
}
