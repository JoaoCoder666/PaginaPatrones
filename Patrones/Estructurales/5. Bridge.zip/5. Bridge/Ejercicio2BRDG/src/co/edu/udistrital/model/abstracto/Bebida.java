package co.edu.udistrital.model.abstracto;

public abstract class Bebida {
	private Temperatura temperatura;
	
	public Bebida(Temperatura temp)
	{
		this.setTemperatura(temp);
	}
	
	public abstract String describir();

	public Temperatura getTemperatura() {
		return temperatura;
	}

	public void setTemperatura(Temperatura temperatura) {
		this.temperatura = temperatura;
	}
}
