package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Temperatura;

public class Caliente implements Temperatura{

	@Override
	public String describir() 
	{
		return ", temperatura: Caliente"; 
	}
}
