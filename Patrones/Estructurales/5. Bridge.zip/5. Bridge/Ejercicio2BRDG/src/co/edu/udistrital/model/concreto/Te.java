package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Bebida;
import co.edu.udistrital.model.abstracto.Temperatura;

public class Te extends Bebida{

	public Te(Temperatura temp) 
	{
		super(temp);
	}

	@Override
	public String describir() 
	{
		return "Te" + this.getTemperatura().describir();
	}
}
