package co.edu.udistrital.model.abstracto;

public interface Temperatura {
	public String describir();
}
