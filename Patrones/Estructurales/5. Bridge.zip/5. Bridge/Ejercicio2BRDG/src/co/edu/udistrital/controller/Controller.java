package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Bebida;
import co.edu.udistrital.model.abstracto.Temperatura;
import co.edu.udistrital.model.concreto.Cafe;
import co.edu.udistrital.model.concreto.Caliente;
import co.edu.udistrital.model.concreto.Frio;
import co.edu.udistrital.model.concreto.Te;
import co.edu.udistrital.view.Vista;

public class Controller {
private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("---Demostracion de la separacion de abstraccion e implementacion---");
		
		Bebida bebida1;
		Bebida bebida2;
		Temperatura temperatura;
		
		vista.mostrarInformacion("Temperatura fria: ");
		temperatura = new Frio();
		
		bebida1 = new Cafe(temperatura);
		bebida2 = new Te(temperatura);
		
		vista.mostrarInformacion(bebida1.describir());
		vista.mostrarInformacion(bebida2.describir());
		
		vista.mostrarInformacion("Temperatura caliente: ");
		temperatura = new Caliente();
		
		bebida1.setTemperatura(temperatura);
		bebida2.setTemperatura(temperatura);
		
		vista.mostrarInformacion(bebida1.describir());
		vista.mostrarInformacion(bebida2.describir());
	}
}
