package co.edu.udistrital.model.concreto;

import co.edu.udistrital.model.abstracto.Bebida;
import co.edu.udistrital.model.abstracto.Temperatura;

public class Cafe extends Bebida{

	public Cafe(Temperatura temp) 
	{
		super(temp);
	}

	@Override
	public String describir() 
	{
		return "Cafe" + this.getTemperatura().describir();
	}
}
