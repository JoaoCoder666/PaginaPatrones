package co.edu.udistrital.model;

public class Pizza {
		private String base;
		private String salsa;
		private String acompa1;
		private String acompa2;
		private String  bebida;
		private int id;

	public Pizza(int id)
	{
		this.id = id;
	}
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	public String getBase() {
		return base;
	}
	public void setBase(String base) {
		this.base = base;
	}
	public String getSalsa() {
		return salsa;
	}
	public void setSalsa(String salsa) {
		this.salsa = salsa;
	}
	public String getAcompa1() {
		return acompa1;
	}
	public void setAcompa1(String acompa1) {
		this.acompa1 = acompa1;
	}
	public String getAcompa2() {
		return acompa2;
	}
	public void setAcompa2(String acompa2) {
		this.acompa2 = acompa2;
	}
	public String getBebida() {
		return bebida;
	}
	public void setBebida(String bebida) {
		this.bebida = bebida;
	}
	
	@Override
	public String toString()
	{
		return "Base: " + this.base + " Salsa: " + this.salsa 
				+ "\nAcomp 1: " + this.acompa1 + " Acomp 2: " + this.acompa2 +""
				+ "\nBebida: " + this.bebida;
	}
}
