package co.edu.udistrital.controller;

import co.edu.udistrital.model.PizzaBuilder;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Bienvenido a pizzas locas, crea tu pizza con los ingredientes que desees");
		
		 String base = "N/A";
		 String salsa = "N/A";
		 String acompa1= "N/A";
		 String acompa2= "N/A";
		 String bebida= "N/A";
		 
		 PizzaBuilder builder = new PizzaBuilder(1).base(base).salsa(salsa).acomp1(acompa1).acomp2(acompa2).bebida(bebida);
		 
		 while(true)
		 {
			 int elecciones = 0;
			 elecciones = vista.leerDatoEntero("Desea agregar una base?"
			 		+ "\n1. si"
			 		+ "\n2. no");
			 if(elecciones == 1)
			 {
				 base = vista.leerCadenaDeTexto("ingrese la base: ");
				 builder.base(base);
				 elecciones = 0;
			 }
			 
			 elecciones = vista.leerDatoEntero("Desea agregar una salsa?"
				 	+ "\n1. si"
				 	+ "'n2. no");
			 if(elecciones == 1)
			 {
				salsa = vista.leerCadenaDeTexto("ingrese la salsa: ");
				builder.salsa(salsa);
				elecciones = 0;
			 }
			 
			 elecciones = vista.leerDatoEntero("Desea Añadir algun acompañamiento?"
					 	+ "\n1. si"
					 	+ "'n2. no");
			 
			 if(elecciones == 1)
			 {
				 acompa1 = vista.leerCadenaDeTexto("Ingrese el primer acompañamiento: ");
				 builder.acomp1(acompa1);
				 acompa2 = vista.leerCadenaDeTexto("Ingrese el segundo acompañamiento: ");
				 builder.acomp2(acompa2);
				 
				 elecciones = 0;
			 }
			
			 elecciones = vista.leerDatoEntero("Desea añadir una bebida?"
			 		+ "\n1. si"
			 		+ "\n2. no");
			 
			 if(elecciones == 1)
			 {
				 bebida = vista.leerCadenaDeTexto("Ingrese la bebida que desea: ");
				 builder.bebida(bebida);
				 elecciones = 0;
			 }
			 
			 vista.mostrarInformacion("Su pedido consiste en una pizza: ");
			 vista.mostrarInformacion(builder.toString());
			 
			 elecciones = vista.leerDatoEntero("Desea: "
			 		+ "1. Ordenar otra pizza"
			 		+ "2. Salir del programa");
			 if(elecciones == 1)
			 {
				 continue;
			 }
			 else if(elecciones == 2)
			 {
				 vista.mostrarInformacion("\nGracias por usar el programa");
				 System.exit(0);
			 }
		 }
	}
}
