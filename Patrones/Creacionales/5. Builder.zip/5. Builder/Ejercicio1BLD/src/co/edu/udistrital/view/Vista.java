package co.edu.udistrital.view;

import java.util.Scanner;

public class Vista {
	private Scanner sc;
	
	public Vista()
	{
		sc = new Scanner(System.in);
	}
	
	public void mostrarInformacion(String mensaje)
	{
		System.out.println(mensaje);
	}
	
	public int leerDatoEntero(String mensaje)
	{
		int aux = 0;
		System.out.println(mensaje);
		aux = Integer.parseInt(sc.nextLine());
		return aux;
	}
	
	public String leerCadenaDeTexto(String mensaje)
	{
		String aux = "";
		System.out.println(mensaje);
		aux = sc.nextLine();
		return aux;
	}
}
