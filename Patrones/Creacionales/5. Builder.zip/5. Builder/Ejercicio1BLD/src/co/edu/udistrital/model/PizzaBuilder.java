package co.edu.udistrital.model;

public class PizzaBuilder {
	private Pizza pizza;
	
	public PizzaBuilder(int id)
	{
		this.pizza = new Pizza(id);
	}
	
	public PizzaBuilder base(String base)
	{
		this.pizza.setBase(base);
		return this;
	}
	
	public PizzaBuilder salsa(String salsa)
	{
		this.pizza.setSalsa(salsa);
		return this;
	}

	public PizzaBuilder acomp1(String acomp1)
	{
		this.pizza.setAcompa1(acomp1);
		return this;
	}
	
	public PizzaBuilder acomp2(String acomp2)
	{
		this.pizza.setAcompa2(acomp2);
		return this;
	}
	
	public PizzaBuilder bebida(String bebida)
	{
		this.pizza.setBebida(bebida);
		return this;
	}
	
	
	@Override
	public String toString()
	{
		return this.pizza.toString();
	}
}
