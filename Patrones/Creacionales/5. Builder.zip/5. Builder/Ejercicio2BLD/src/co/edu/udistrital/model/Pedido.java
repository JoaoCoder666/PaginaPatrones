package co.edu.udistrital.model;

public class Pedido {
	private String frutas;
	private String verduras;
	private String lacteos;
	private String bebidas;
	private int id;
	
	public Pedido(int id)
	{
		this.id = id;
	}
	
	@Override
	public String toString()
	{
		return "Frutas: " + this.frutas + ", Verduras: " + this.verduras 
				+ "\n Lacteos: " + this.lacteos + ", bebidas: " + this.bebidas;
	}

	public String getFrutas() {
		return frutas;
	}

	public void setFrutas(String frutas) {
		this.frutas = frutas;
	}

	public String getVerduras() {
		return verduras;
	}

	public void setVerduras(String verduras) {
		this.verduras = verduras;
	}

	public String getLacteos() {
		return lacteos;
	}

	public void setLacteos(String lacteos) {
		this.lacteos = lacteos;
	}

	public String getBebidas() {
		return bebidas;
	}

	public void setBebidas(String bebidas) {
		this.bebidas = bebidas;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
}
