package co.edu.udistrital.model;

public class PedidosBuilder {
	private Pedido pedido;
	
	public PedidosBuilder(int id)
	{
		this.pedido = new Pedido(id);
	}
	
	public PedidosBuilder frutas(String futas)
	{
		this.pedido.setFrutas(futas);
		return this;
	}
	
	public PedidosBuilder verduras(String verduras)
	{
		this.pedido.setVerduras(verduras);
		return this;
	}
	
	public PedidosBuilder lacteos(String lacteos)
	{
		this.pedido.setLacteos(lacteos);
		return this;
	}
	
	public PedidosBuilder bebidas(String bebidas)
	{
		this.pedido.setBebidas(bebidas);
		return this;
	}
	
	@Override
	public String toString()
	{
		return this.pedido.toString();
	}
}
