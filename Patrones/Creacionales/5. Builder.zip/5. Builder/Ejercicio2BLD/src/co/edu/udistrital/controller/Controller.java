package co.edu.udistrital.controller;

import co.edu.udistrital.model.PedidosBuilder;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Bienvenido a mercaOnline, haz tu pedido con un elemento de cada categoria: ");
		
		String frutas = "N/A";
		String verduras = "N/A";
		String lacteos = "N/A";
		String bebidas = "N/A";
		
		PedidosBuilder pedido = new PedidosBuilder(1).frutas(frutas).verduras(verduras).lacteos(lacteos).bebidas(bebidas);
		
		while(true)
		{
			int elecciones = 0;
			elecciones = vista.leerDatoEntero("Desea agregar una fruta: "
			+ "\n1.si"
			+ "\n2.no");
			
			if(elecciones == 1)
			{
				frutas = vista.leerCadenaDeTexto("Ingrese la fruta a eleccion: ");
				pedido.frutas(frutas);
				elecciones = 0;
			}
			
			elecciones = vista.leerDatoEntero("Desea agregar una verdura: "
			+ "\n1.si"
			+ "\n2.no");
			
			if(elecciones == 1)
			{
				verduras = vista.leerCadenaDeTexto("Ingrese la verdura a eleccion: ");
				pedido.verduras(verduras);
				elecciones = 0;
			}
			
			elecciones = vista.leerDatoEntero("Desea agregar un lacteo: "
			+ "\n1.si"
			+ "\n2.no");
			
			if(elecciones == 1)
			{
				lacteos = vista.leerCadenaDeTexto("Ingrese el lacteo a eleccion: ");
				pedido.lacteos(lacteos);
				elecciones = 0;
			}
			
			elecciones = vista.leerDatoEntero("Desea agregar una bebida: "
			+ "\n1.si"
			+ "\n2.no");
			
			if(elecciones == 1)
			{
				bebidas = vista.leerCadenaDeTexto("Ingrese la bebida a eleccion: ");
				pedido.bebidas(bebidas);
				elecciones = 0;
			}
			
			vista.mostrarInformacion("Su pedido consiste en: \n" + pedido.toString());
			
			elecciones = vista.leerDatoEntero("Desea: "
			 		+ "1. Realizar otro pedido"
			 		+ "2. Salir del programa");
			 if(elecciones == 1)
			 {
				 continue;
			 }
			 else if(elecciones == 2)
			 {
				 vista.mostrarInformacion("\nGracias por usar el programa");
				 System.exit(0);
			 }
		}
	}
}

