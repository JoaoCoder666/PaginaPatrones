package co.edu.udistrital.model;

public class Personaje {
	private String nombre;
	private String raza;
	private String clase;
	private int fuerza;
	private int aguante;
	private int id;
	
	public Personaje(int id)
	{
		this.id = id;
	}
	
	@Override
	public String toString()
	{
		return "Nombre: " + this.nombre + ", raza: " + this.raza + ", clase: " + this.clase
				+ "\nFuerza: " + this.fuerza + ", aguante: " + this.aguante;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getRaza() {
		return raza;
	}

	public void setRaza(String raza) {
		this.raza = raza;
	}

	public String getClase() {
		return clase;
	}

	public void setClase(String clase) {
		this.clase = clase;
	}

	public int getFuerza() {
		return fuerza;
	}

	public void setFuerza(int fuerza) {
		this.fuerza = fuerza;
	}

	public int getAguante() {
		return aguante;
	}

	public void setAguante(int aguante) {
		this.aguante = aguante;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}
	
	
}
