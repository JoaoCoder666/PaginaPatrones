package co.edu.udistrital.controller;

import co.edu.udistrital.model.PersonajeBuilder;
import co.edu.udistrital.view.Vista;

public class Controller {
	private Vista vista;
	
	public Controller()
	{
		vista = new Vista();
	}
	
	public void run()
	{
		vista.mostrarInformacion("Bienvenido al creador de personajes, customiza el tuyo: ");
		
		String nombre = "Generico";
		String raza = "Generica"; 
		String clase = "Generica";
		int fuerza = 10;
		int aguante = 10;
		
		PersonajeBuilder builder = new PersonajeBuilder(1).nombre(nombre).raza(raza).clase(clase).fuerza(fuerza).aguante(aguante);
		
		while(true)
		{
			int elecciones = 0;
			
			elecciones = vista.leerDatoEntero("Desea elegir un nombre personalizado? "
							+ "\n1.si"
							+ "\n2.no");
		
			if(elecciones == 1)
			{
				nombre = vista.leerCadenaDeTexto("Ingrese el nombre: ");
				builder.nombre(nombre);
				elecciones = 0;
			}
			
			elecciones = vista.leerDatoEntero("Desea elegir una raza personalizada? "
					+ "\n1.si"
					+ "\n2.no");

			if(elecciones == 1)
			{
				raza = vista.leerCadenaDeTexto("Ingrese la raza: ");
				builder.raza(raza);
				elecciones = 0;
			}
			
			elecciones = vista.leerDatoEntero("Desea elegir una clase personalizada? "
					+ "\n1.si"
					+ "\n2.no");

			if(elecciones == 1)
			{
				clase = vista.leerCadenaDeTexto("Ingrese la clase: ");
				builder.clase(clase);
				elecciones = 0;
			}
			
			elecciones = vista.leerDatoEntero("Desea modificar la fuerza? "
					+ "\n1.si"
					+ "\n2.no");

			if(elecciones == 1)
			{
				fuerza = Integer.parseInt(vista.leerCadenaDeTexto("Ingrese la fuerza (int): "));
				builder.fuerza(fuerza);
				elecciones = 0;
			}
			
			elecciones = vista.leerDatoEntero("Desea modificar el aguante? "
					+ "\n1.si"
					+ "\n2.no");

			if(elecciones == 1)
			{
				aguante = Integer.parseInt(vista.leerCadenaDeTexto("Ingrese el aguante (int): "));
				builder.aguante(aguante);
				elecciones = 0;
			}
			
			vista.mostrarInformacion("Su personaje: \n" + builder.toString());
			
			elecciones = vista.leerDatoEntero("Desea: "
			 		+ "1. Crear otro personaje"
			 		+ "2. Salir del programa");
			 if(elecciones == 1)
			 {
				 continue;
			 }
			 else if(elecciones == 2)
			 {
				 vista.mostrarInformacion("\nGracias por usar el programa");
				 System.exit(0);
			 }
		}
	}
}
