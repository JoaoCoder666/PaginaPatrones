package co.edu.udistrital.model;

public class PersonajeBuilder {
	private Personaje personaje;
	
	public PersonajeBuilder(int id)
	{
		this.personaje = new Personaje(id);
	}
	
	@Override
	public String toString()
	{
		return this.personaje.toString();
	}
	
	public PersonajeBuilder nombre(String nombre)
	{
		this.personaje.setNombre(nombre);
		return this;
	}
	
	public PersonajeBuilder raza(String raza)
	{
		this.personaje.setRaza(raza);
		return this;
	}
	
	public PersonajeBuilder clase(String clase)
	{
		this.personaje.setClase(clase);
		return this;
	}
	
	public PersonajeBuilder fuerza(int fuerza)
	{
		this.personaje.setFuerza(fuerza);
		return this;
	}
	
	public PersonajeBuilder aguante(int aguante)
	{
		this.personaje.setAguante(aguante);
		return this;
	}
}
