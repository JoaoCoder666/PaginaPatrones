package co.edu.udistrital.view;

import java.util.Scanner;

public class VistaConsola {
	private Scanner sc;
	
	public VistaConsola()
	{
		sc = new Scanner(System.in);
	}
	
	public void mostrarInformacion(String mensaje)
	{
		System.out.print("\n" + mensaje);
	}
	
	public int leerDatoEntero(String mensaje)
	{
		int n = 0;
		System.out.print("\n" + mensaje);
		n = sc.nextInt();
		return n;
	}
	
	public String leerCadenaDeTexto(String mensaje)
	{
		System.out.print("\n" + mensaje);
		return sc.nextLine();
	}
}
