	package co.edu.udistrital.model;

public class Impresora {
	public static Impresora instancia = null;
	private String pruebaInstancia = "";
	
	private Impresora(){}

	public static Impresora getInstancia() {
		if(instancia == null)
		{
			instancia = new Impresora();
		}
		return instancia;
	}

	public static void setInstancia(Impresora instancia) {
		Impresora.instancia = instancia;
	}

	public String getPruebaInstancia() {
		return pruebaInstancia;
	}

	public void setPruebaInstancia(String pruebaInstancia) {
		this.pruebaInstancia = pruebaInstancia;
	}
}
