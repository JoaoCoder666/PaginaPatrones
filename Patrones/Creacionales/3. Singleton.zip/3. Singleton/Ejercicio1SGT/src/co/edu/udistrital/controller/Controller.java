package co.edu.udistrital.controller;

import co.edu.udistrital.model.Impresora;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{
		Impresora obj = Impresora.getInstancia();
		Impresora obj2Prueba = Impresora.getInstancia();
		
		obj.setPruebaInstancia("Quinto piso");
		vista.mostrarInformacion(obj2Prueba.getPruebaInstancia());
	}
}
