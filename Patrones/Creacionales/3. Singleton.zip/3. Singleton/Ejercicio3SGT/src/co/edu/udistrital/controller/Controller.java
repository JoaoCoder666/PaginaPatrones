package co.edu.udistrital.controller;

import co.edu.udistrital.model.CedulaCiudanania;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{
		CedulaCiudanania obj = CedulaCiudanania.getInstancia();
		obj.setNombrePersona("Roman");
		CedulaCiudanania obj2Prueba = CedulaCiudanania.getInstancia();
		
		obj.setPruebaInstancia("1234567890");
		vista.mostrarInformacion("Persona: " +obj2Prueba.getNombrePersona() + " CC: " +  obj2Prueba.getPruebaInstancia());
	}
}
