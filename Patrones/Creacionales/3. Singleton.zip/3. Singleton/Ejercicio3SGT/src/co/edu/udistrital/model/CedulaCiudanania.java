package co.edu.udistrital.model;

public class CedulaCiudanania {
	public static CedulaCiudanania instancia = null;
	private String pruebaInstancia = "";
	private String nombrePersona = "";
	
	public static CedulaCiudanania getInstancia() {
		if(instancia == null)
		{
			instancia = new CedulaCiudanania();
		}
		return instancia;
	}

	public static void setInstancia(CedulaCiudanania instancia) {
		CedulaCiudanania.instancia = instancia;
	}

	public String getPruebaInstancia() {
		return pruebaInstancia;
	}

	public void setPruebaInstancia(String pruebaInstancia) {
		this.pruebaInstancia = pruebaInstancia;
	}

	public String getNombrePersona() {
		return nombrePersona;
	}

	public void setNombrePersona(String nombrePersona) {
		this.nombrePersona = nombrePersona;
	}

	private CedulaCiudanania() {}
}
