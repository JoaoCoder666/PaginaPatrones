package co.edu.udistrital.model;

public class DiscoPrincipal {
	public static DiscoPrincipal instancia = null;
	private String pruebaInstancia = "";
	
	public static DiscoPrincipal getInstancia() 
	{
		if(instancia == null)
		{
			instancia = new DiscoPrincipal();
		}
		return instancia;
	}
	public static void setInstancia(DiscoPrincipal instancia) {
		DiscoPrincipal.instancia = instancia;
	}
	public String getPruebaInstancia() {
		return pruebaInstancia;
	}
	public void setPruebaInstancia(String pruebaInstancia) {
		this.pruebaInstancia = pruebaInstancia;
	}
	
	private DiscoPrincipal() {}
}
