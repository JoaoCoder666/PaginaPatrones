package co.edu.udistrital.controller;

import co.edu.udistrital.model.DiscoPrincipal;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{
		DiscoPrincipal obj = DiscoPrincipal.getInstancia();
		DiscoPrincipal obj2Prueba = DiscoPrincipal.getInstancia();
		
		obj.setPruebaInstancia("Disco SSD 1TB");
		vista.mostrarInformacion(obj2Prueba.getPruebaInstancia());
	}
}
