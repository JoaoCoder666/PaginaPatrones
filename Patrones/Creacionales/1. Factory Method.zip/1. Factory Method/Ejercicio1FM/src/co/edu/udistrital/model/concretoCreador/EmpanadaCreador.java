package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.abstracto.*;
import co.edu.udsitrital.model.Carne;
import co.edu.udsitrital.model.Pollo;

public class EmpanadaCreador implements EmpanadaFactory{

	
	@Override
	public Empanada crearEmpanada(String proteina, String acomp) {
		if(proteina.equals("Carne") || proteina.equals("carne"))
		{
			return new Carne("Carne", acomp);
		}
		else if(proteina.equals("Pollo") || proteina.equals("pollo"))
		{
			return new Pollo("Pollo", acomp);
		}
		return null;
	}

}
