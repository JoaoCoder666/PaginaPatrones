package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Empanada;
import co.edu.udistrital.model.abstracto.EmpanadaFactory;
import co.edu.udistrital.model.concretoCreador.EmpanadaCreador;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{
		String p = "";
		String r = "";
		
		vista.mostrarInformacion("Ingrerse los datos del pedido");
		p = vista.leerCadenaDeTexto("Proteina"
					+ "\nPollo o Carne");
		r = vista.leerCadenaDeTexto("Relleno"
					+ "\nArroz o Papa");
		
		EmpanadaFactory fabrica = new EmpanadaCreador();
		
		Empanada empanada = fabrica.crearEmpanada(p, r);
		
		vista.mostrarInformacion("Su pedido es un empanada de:"
				+ "\n" + empanada.describir());
	}
}
