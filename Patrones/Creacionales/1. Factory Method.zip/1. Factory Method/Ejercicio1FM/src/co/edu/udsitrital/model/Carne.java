package co.edu.udsitrital.model;

import co.edu.udistrital.model.abstracto.Empanada;

public class Carne extends Empanada{

	public Carne(String proteina, String acomp) {
		super(proteina, acomp);
	}

	@Override
	public String describir()
	{
		return "---Carne con " + acomp + "---";
	}
}
