package co.edu.udsitrital.model;

import co.edu.udistrital.model.abstracto.Empanada;

public class Pollo extends Empanada{

	public Pollo(String proteina, String acomp) {
		super(proteina, acomp);
	}
	
	@Override
	public String describir()
	{
		return "---Pollo con " + acomp + "---";
	}
}
