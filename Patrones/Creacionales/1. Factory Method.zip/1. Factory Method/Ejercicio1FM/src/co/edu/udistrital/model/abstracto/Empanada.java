package co.edu.udistrital.model.abstracto;

public abstract class Empanada {
	protected String proteina;
	protected String acomp;
	
	public Empanada(String proteina, String acomp)
	{
		this.proteina = proteina;
		this.acomp = acomp;
	}
	
	public abstract String describir();
}
