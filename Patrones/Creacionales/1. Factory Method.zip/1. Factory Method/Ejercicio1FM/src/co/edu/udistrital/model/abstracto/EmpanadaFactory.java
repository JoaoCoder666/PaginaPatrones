package co.edu.udistrital.model.abstracto;

public interface EmpanadaFactory {	
	Empanada crearEmpanada(String proteina, String acomp);
}
