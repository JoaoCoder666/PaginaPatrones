package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Jugador;

public class Delantero extends Jugador{

	public Delantero(String pD, String cR) 
	{
		super(pD, cR);
	}

	public String describir()
	{
		return "--Delantero"
				+ "\nPie habil: " + pieDominante
				+ "\nCaracteristica principal: " + complementoRol
				+ "\nObjetivo: Marcar goles";
	}
}
