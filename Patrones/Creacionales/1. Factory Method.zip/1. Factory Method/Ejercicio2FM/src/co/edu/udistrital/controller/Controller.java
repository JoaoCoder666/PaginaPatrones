package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Jugador;
import co.edu.udistrital.model.abstracto.JugadorFactory;
import co.edu.udistrital.model.concretoCreador.JugadorCreador;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{
		String pD = "";
		String cR = "";
		
		vista.mostrarInformacion("Ingrerse las caracteristicas de su jugador");
		pD = vista.leerCadenaDeTexto("Pie dominante: "
						+ "\nDerecho o Izquierdo");
		cR = vista.leerCadenaDeTexto("Rol en el campo: "
						+ "\nAtacar, atacar y defender, defender");
		
		JugadorFactory fabrica = new JugadorCreador();
		
		Jugador jugador = fabrica.crearJugador(pD, cR);
			
		vista.mostrarInformacion("Su jugador:"
				+ "\n" + jugador.describir());		
	}
}
