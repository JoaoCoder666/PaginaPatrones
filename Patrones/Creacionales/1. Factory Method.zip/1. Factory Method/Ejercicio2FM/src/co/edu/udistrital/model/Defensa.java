package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Jugador;

public class Defensa extends Jugador{

	public Defensa(String pD, String cR) 
	{
		super(pD, cR);
	}

	@Override
	public String describir()
	{
		return "--Defensa"
				+ "\nPie habil: " + pieDominante
				+ "\nCaracteristica principal: " + complementoRol
				+ "\nObjetivo: Recuperar la posesion";
	}
	
}
