package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Jugador;

public class MedioCentro extends Jugador{

	public MedioCentro(String pD, String cR) 
	{
		super(pD, cR);
	}
	
	@Override
	public String describir()
	{
		return "--Medio Centro"
				+ "\nPie habil: " + pieDominante
				+ "\nCaracteristica principal: " + complementoRol
				+ "\nObjetivo: crear juego";
	}
}

