package co.edu.udistrital.model.abstracto;

public interface JugadorFactory {
	
	Jugador crearJugador(String pD, String cR);
}
