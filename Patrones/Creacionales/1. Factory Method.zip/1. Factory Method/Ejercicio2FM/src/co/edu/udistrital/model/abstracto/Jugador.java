package co.edu.udistrital.model.abstracto;

public abstract class Jugador {
	protected String pieDominante;
	protected String complementoRol;
	
	public Jugador(String pD, String cR)
	{
		this.pieDominante  = pD;
		this.complementoRol = cR;
	}
	
	public abstract String describir();
}
