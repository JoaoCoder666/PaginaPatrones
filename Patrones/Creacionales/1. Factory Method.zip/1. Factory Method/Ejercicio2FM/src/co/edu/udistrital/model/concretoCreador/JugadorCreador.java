package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.*;
import co.edu.udistrital.model.abstracto.Jugador;
import co.edu.udistrital.model.abstracto.JugadorFactory;

public class JugadorCreador implements JugadorFactory{

	@Override
	public Jugador crearJugador(String pD, String cR)
	{
		String lowerCcR = cR.toLowerCase();
		
		if(lowerCcR.contains("atacar"))
		{
			return new Delantero(pD, cR);
		}
		else if(lowerCcR.contains("atacar y defender"))
		{
			return new MedioCentro(pD, cR);
		}
		else if(lowerCcR.equals("defender"))
		{
			return new Defensa(pD, cR);
		}
		else
		{
			return null;
		}
	}
}
