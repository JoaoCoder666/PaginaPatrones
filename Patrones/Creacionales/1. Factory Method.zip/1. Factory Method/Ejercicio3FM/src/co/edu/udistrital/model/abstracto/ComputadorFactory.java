package co.edu.udistrital.model.abstracto;

public interface ComputadorFactory {
	
	Computador crearComputador(String esP, String mYC);
}
