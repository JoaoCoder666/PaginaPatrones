package co.edu.udistrital.model.abstracto;

public abstract class Computador {
	protected String esPortable;
	protected String monitorYCuerpo;
	
	public Computador(String esP, String mYC)
	{
		this.esPortable = esP;
		this.monitorYCuerpo = mYC;
	}
	
	public abstract String describir();
}
