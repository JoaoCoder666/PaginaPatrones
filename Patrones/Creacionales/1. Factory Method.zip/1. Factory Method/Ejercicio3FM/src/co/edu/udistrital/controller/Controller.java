package co.edu.udistrital.controller;

import co.edu.udistrital.model.abstracto.Computador;
import co.edu.udistrital.model.abstracto.ComputadorFactory;
import co.edu.udistrital.model.concretoCreador.ComputadorCreador;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{
		String esP = "";
		String mYC = "";
		
		vista.mostrarInformacion("Ingrerse los datos del equipo que busca");
		esP = vista.leerCadenaDeTexto("Es portable?"
					+ "\nSi o No");
		mYC = vista.leerCadenaDeTexto("El monitor y el cpu vienen integrados en el mismo chasis?"
					+ "\nSi o No");
		
		ComputadorFactory fabrica = new ComputadorCreador();
		
		Computador computador = fabrica.crearComputador(esP, mYC); 	
		
		vista.mostrarInformacion("El equipo que busca es un: "
				+ "\n" + computador.describir());
	}
}
