package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Computador;

public class Laptop extends Computador{

	public Laptop(String esP, String mYC) 
	{
		super(esP, mYC);
	}

	@Override
	public String describir()
	{
		return "---Laptop---";
	}
}
