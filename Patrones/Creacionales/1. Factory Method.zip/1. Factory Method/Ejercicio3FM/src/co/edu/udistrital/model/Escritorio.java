package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Computador;

public class Escritorio extends Computador{

	public Escritorio(String esP, String mYC) 
	{
		super(esP, mYC);
	}

	@Override
	public String describir()
	{
		return "---Computador de escritorio---";
	}
}
