package co.edu.udistrital.model.concretoCreador;

import co.edu.udistrital.model.AllinOne;
import co.edu.udistrital.model.Escritorio;
import co.edu.udistrital.model.Laptop;
import co.edu.udistrital.model.abstracto.Computador;
import co.edu.udistrital.model.abstracto.ComputadorFactory;

public class ComputadorCreador implements ComputadorFactory{
	
	public Computador crearComputador(String esP, String mYC)
	{
		String esPLC = esP.toLowerCase();
		String mYCLC = mYC.toLowerCase();
		
		if(esPLC.equals("si") && mYCLC.equals("si"))
		{
			return new Laptop(esP, mYC);
		}
		else if(esPLC.equals("no"))
		{
			if(mYCLC.equals("si"))
			{
				return new AllinOne(esP, mYC);
			}
			else if(mYCLC.equals("no"))
			{
				return new Escritorio(esP, mYC);
			}
			else
			{
				return null;
			}
		}
		else
		{
			return null;
		}
	}
}
