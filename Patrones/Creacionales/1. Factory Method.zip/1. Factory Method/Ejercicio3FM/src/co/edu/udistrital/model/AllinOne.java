package co.edu.udistrital.model;

import co.edu.udistrital.model.abstracto.Computador;

public class AllinOne extends Computador{

	public AllinOne(String esP, String mYC) 
	{
		super(esP, mYC);
	}

	@Override
	public String describir()
	{
		return "---Computador All in One---";
	}
}
