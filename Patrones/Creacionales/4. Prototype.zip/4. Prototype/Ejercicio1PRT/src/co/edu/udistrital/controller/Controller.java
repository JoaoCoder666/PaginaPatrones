package co.edu.udistrital.controller;

import co.edu.udistrital.model.Caballero;
import co.edu.udistrital.model.Mago;
import co.edu.udistrital.model.NoMuerto;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{	
		Caballero caballeroBase = Caballero.caballeroBase()	;
		Mago magoBase = Mago.magoBase();		
		NoMuerto noMuertoBase = NoMuerto.NoMuertoBase();
		
		vista.mostrarInformacion("Creador de personajes: "
				+ "\nCaballero Base: " + caballeroBase.toString()
				+ "\nMago Base: " + magoBase.toString()
				+ "\nNo Muerto Base: " + noMuertoBase.toString());
		
		vista.mostrarInformacion("\n\nCLONACION\n\n");
		
		Caballero caballeroClonado = (Caballero) caballeroBase.clone();
		caballeroClonado.setSpecialAbl("Ataque Aereo");
		
		Mago  magoClonado = (Mago) magoBase.clone();
		magoClonado.setSpecialAbl("Sacrificio");
		
		NoMuerto noMuertoClonado = (NoMuerto) noMuertoBase.clone();
		noMuertoClonado.setSpecialAbl("Resucitar");
		
		vista.mostrarInformacion("---Caballeros---"
				+ "\nBase: " + caballeroBase.toString()
				+ "\nClonado: " + caballeroClonado.toString());
		
		vista.mostrarInformacion("---Magos---"
				+ "\nBase: " + magoBase.toString()
				+ "\nClonado: " + magoClonado.toString());		
		
		vista.mostrarInformacion("---No Muertos---"
				+ "\nBase: " + noMuertoBase.toString()
				+ "\nClonado: " + noMuertoClonado.toString());
		
	}
}
