package co.edu.udistrital.model;

import co.edu.udistrital.abstractModel.Personaje;

public class Mago extends Personaje{
	
	public Mago() {}
	
	public Mago(Mago mago)
	{
		super(mago);
	}

	@Override
	public Personaje clone() {
		return new Mago(this);
	}
	
	public static Mago magoBase()
	{
		Mago m = new Mago();
		m.setHealthPoints("700");
		m.setAttPerSec("70");
		m.setSpecialAbl("Invocacion");
		return m;
	}
	
	@Override
	public String toString()
	{
		return "\nPuntos de vida: " + super.healthPoints + " Daño por segundo: " + super.attPerSec + " Habilidad especial: " + super.specialAbl;
	}
}
