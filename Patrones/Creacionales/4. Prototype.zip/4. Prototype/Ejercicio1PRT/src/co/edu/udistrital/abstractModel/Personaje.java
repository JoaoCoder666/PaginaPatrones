package co.edu.udistrital.abstractModel;

public abstract class Personaje {
	protected String healthPoints;
	protected String attPerSec;
	protected String specialAbl;
	
	protected Personaje() {}
	
	protected Personaje(Personaje personaje)
	{
		this.healthPoints = personaje.healthPoints;
		this.attPerSec = personaje.attPerSec;
		this.specialAbl = personaje.specialAbl;
	}
	
	public abstract Personaje clone();

	public String getHealthPoints() {
		return healthPoints;
	}

	public void setHealthPoints(String healthPoints) {
		this.healthPoints = healthPoints;
	}

	public String getAttPerSec() {
		return attPerSec;
	}

	public void setAttPerSec(String attPerSec) {
		this.attPerSec = attPerSec;
	}

	public String getSpecialAbl() {
		return specialAbl;
	}

	public void setSpecialAbl(String specialAbl) {
		this.specialAbl = specialAbl;
	}
	
	
}
