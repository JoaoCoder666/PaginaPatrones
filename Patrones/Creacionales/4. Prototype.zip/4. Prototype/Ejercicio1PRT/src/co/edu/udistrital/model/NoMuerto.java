package co.edu.udistrital.model;

import co.edu.udistrital.abstractModel.Personaje;

public class NoMuerto extends Personaje{
	
	public NoMuerto() {}
	
	public NoMuerto(NoMuerto noMuerto)
	{
		super(noMuerto);
	}

	@Override
	public Personaje clone() {
		return new NoMuerto(this);
	}
	
	public static NoMuerto NoMuertoBase()
	{
		NoMuerto nM = new NoMuerto();
		nM.setHealthPoints("600");
		nM.setAttPerSec("80");
		nM.setSpecialAbl("Envenenar");
		return nM;
	}
	
	@Override
	public String toString()
	{
		return "\nPuntos de vida: " + super.healthPoints + " Daño por segundo: " + super.attPerSec + " Habilidad especial: " + super.specialAbl;
	}
}
