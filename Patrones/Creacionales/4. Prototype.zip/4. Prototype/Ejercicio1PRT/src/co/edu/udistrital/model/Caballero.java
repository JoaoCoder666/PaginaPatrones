package co.edu.udistrital.model;

import co.edu.udistrital.abstractModel.Personaje;

public class Caballero extends Personaje{

	public Caballero() {}
	
	public Caballero(Caballero caballero)
	{
		super(caballero);
	}
	
	@Override
	public Personaje clone() {
		return new Caballero(this);
	}
		
	public static Caballero caballeroBase()
	{
		Caballero c = new Caballero();
		c.setHealthPoints("1000");
		c.setAttPerSec("40");
		c.setSpecialAbl("Estocada");
		return c;
	}
	
	@Override
	public String toString()
	{
		return "\nPuntos de vida: " + super.healthPoints + " Daño por segundo: " + super.attPerSec + " Habilidad especial: " + super.specialAbl;
	}
}
