package co.edu.udistrital.abstractModel;

public abstract class Guitarra {
	protected String cantCuerdas;
	protected String cantTrastes;
	protected String tipoPuente;
	
	public Guitarra() {}
	
	public Guitarra(Guitarra guitarra)
	{
		this.cantCuerdas = guitarra.cantCuerdas;
		this.cantTrastes = guitarra.cantTrastes;
		this.tipoPuente = guitarra.tipoPuente;
	}
	
	public abstract Guitarra clone();

	public String getCantCuerdas() {
		return cantCuerdas;
	}

	public void setCantCuerdas(String cantCuerdas) {
		this.cantCuerdas = cantCuerdas;
	}

	public String getCantTrastes() {
		return cantTrastes;
	}

	public void setCantTrastes(String cantTrastes) {
		this.cantTrastes = cantTrastes;
	}

	public String getTipoPuente() {
		return tipoPuente;
	}

	public void setTipoPuente(String tipoPuente) {
		this.tipoPuente = tipoPuente;
	}
	
	
}
