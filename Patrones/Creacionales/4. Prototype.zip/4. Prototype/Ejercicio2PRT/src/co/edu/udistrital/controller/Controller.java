package co.edu.udistrital.controller;

import co.edu.udistrital.model.GuitarraConcreta;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{
		GuitarraConcreta guitBase = GuitarraConcreta.guitarraBase();
		
		vista.mostrarInformacion("Creador de guitarras");
		vista.mostrarInformacion("Guitarra Base: " + guitBase.toString());
		
		GuitarraConcreta guitClonada1 = (GuitarraConcreta) guitBase.clone();
		guitClonada1.setCantCuerdas("7");
		guitClonada1.setTipoPuente("Flotante");
		
		GuitarraConcreta guitClonada2 = (GuitarraConcreta) guitBase.clone();
		guitClonada2.setCantTrastes("24");
		guitClonada2.setTipoPuente("Semi flotante");
		
		vista.mostrarInformacion("------CLONACION------\n\n");
		
		vista.mostrarInformacion("Guitarras:"
				+ "\nBase: " + guitBase.toString()
				+ "\nClonada 1: " + guitClonada1.toString()
				+ "\nClonada 2: " + guitClonada2.toString());
	}
}
