package co.edu.udistrital.model;

import co.edu.udistrital.abstractModel.Guitarra;

public class GuitarraConcreta extends Guitarra{
	
	public GuitarraConcreta() {};
	
	public GuitarraConcreta(GuitarraConcreta guitCon)
	{
		super(guitCon);
	}
	
	public static GuitarraConcreta guitarraBase()
	{
		GuitarraConcreta gC = new GuitarraConcreta();
		gC.setCantCuerdas("6");
		gC.setCantTrastes("22");
		gC.setTipoPuente("fijo");
		
		return gC;
	}
	
	public GuitarraConcreta clone()
	{
		return new GuitarraConcreta(this);
	}
	
	@Override
	public String toString()
	{
		return "Cantidad cuerdas: " + super.cantCuerdas + ", Cantidad trastes: " + super.cantTrastes + ", Tipo de puente: " + super.tipoPuente;
	}
}
