package co.edu.udistrital.abstractModel;

public abstract class Audifonos {
	protected String tipo;
	protected String cancelacionRuido;
	protected String conectividad;
	
	public Audifonos() {}
	
	public Audifonos(Audifonos audifonos)
	{
		this.tipo = audifonos.tipo;
		this.cancelacionRuido = audifonos.cancelacionRuido;
		this.conectividad = audifonos.conectividad;
	}
	
	public abstract Audifonos clone();

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public String getCancelacionRuido() {
		return cancelacionRuido;
	}

	public void setCancelacionRuido(String cancelacionRuido) {
		this.cancelacionRuido = cancelacionRuido;
	}

	public String getConectividad() {
		return conectividad;
	}

	public void setConectividad(String conectividad) {
		this.conectividad = conectividad;
	}
	
}
