package co.edu.udistrital.model;

import co.edu.udistrital.abstractModel.Audifonos;

public class AudifonosConcretos extends Audifonos{
	
	public AudifonosConcretos() {}
	
	public AudifonosConcretos(AudifonosConcretos audCon)
	{
		super(audCon);
	}
	
	public AudifonosConcretos clone()
	{
		return new AudifonosConcretos(this);
	}
	
	
	public static AudifonosConcretos audifonosBase()
	{
		AudifonosConcretos aC = new AudifonosConcretos();
		aC.setTipo("auriculares");
		aC.setCancelacionRuido("N/A");
		aC.setConectividad("Cable");
		
		return aC;
	}
	
	
	@Override
	public String toString()
	{
		return "Tipo: " + super.tipo + ", Cancelacion de ruido: " + super.cancelacionRuido + ", Conectividad: " + super.conectividad;
	}
}
