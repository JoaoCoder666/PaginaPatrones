package co.edu.udistrital.controller;

import co.edu.udistrital.model.AudifonosConcretos;
import co.edu.udistrital.view.VistaConsola;

public class Controller {
	private VistaConsola vista;
	
	public Controller()
	{
		vista = new VistaConsola();
	}
	
	public void run()
	{
		AudifonosConcretos audifonosBase = AudifonosConcretos.audifonosBase();
		
		vista.mostrarInformacion("Creador de audifonos y auriculares");
		vista.mostrarInformacion("Audifonos Base: " + audifonosBase.toString());
		
		AudifonosConcretos audClonados1 = (AudifonosConcretos) audifonosBase.clone();
		audClonados1.setCancelacionRuido("Activa");
		audClonados1.setConectividad("Bluetooth");
		
		AudifonosConcretos audClonados2 = (AudifonosConcretos) audifonosBase.clone();
		audClonados2.setTipo("Diadema");
		audClonados2.setCancelacionRuido("Pasiva");
		
		vista.mostrarInformacion("------CLONACION------");
		vista.mostrarInformacion("Audifonos: "
				+ "\nBase: " + audifonosBase.toString()
				+ "\nClonados 1: " + audClonados1.toString()
				+ "\nClonados 2: " + audClonados2.toString());
	}
}
